package interfaces;

import java.awt.Graphics;

public interface GenerciMobIntarface {

	public void drawMobHp(Graphics g);
}
