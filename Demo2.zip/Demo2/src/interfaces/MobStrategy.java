package interfaces;
import demo1.*;

public interface MobStrategy {

	public void update(int mc_x,int mc_y,GenericMob mob);
	
}
