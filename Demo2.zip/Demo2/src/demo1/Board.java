package demo1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Board extends JPanel implements ActionListener, Observer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final int WIDTH = 800; // window's width
	private final int HEIGHT = 600; // window's height
	private final int DELAY = 13; // timer delay

	private Timer timer; // timer to repaint the window

	private Loser loser;

	private GameLogic gameLogic;

	private boolean change = false;

	/// Constructor of the Board class
	public Board() {
		setFocusable(true);
		initBoard();
	}

	/// Initialize the window, the main character and the mobsS
	private void initBoard() {
		addKeyListener(new TAdapter());
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(WIDTH, HEIGHT));

		gameLogic = new GameLogic();
		gameLogic.addObserver(this);

		loser = new Loser();

		change = true;

		timer = new Timer(DELAY, this);
		timer.start();

	}

	/// Draws all the objects
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (change) {
			gameLogic.initMap();
			change = false;
		}

		if (gameLogic.isDeath()) {
			loser.drawGameOver(g, this);
			gameLogic.getGd().showDialog(g, this, " YOU DIED ", 1);
		} else {
			drawObjects(g);
		}
		Toolkit.getDefaultToolkit().sync();
	}

	// Draws the objects if the game is not over yet
	// (Main character, mobs, generic map element, shot)
	public void drawObjects(Graphics g) {
		g.drawImage(gameLogic.getMg().getBackground(), 0, 0, this);

		/*
		 * DRAW MAIN CHARACTER SHOTS
		 */
		List<Shot> shots_list = gameLogic.getMc().GetShots();
		for (Shot shot : shots_list) {
			if (shot.isVisible())
				g.drawImage(shot.getImage(), shot.getX(), shot.getY(), this);
		}

		/*
		 * DRAW ALL THE MAP
		 */
		for (MapElement mp : gameLogic.getMap()) {
			if (mp.isVisible())
				g.drawImage(mp.getImage(), mp.getX(), mp.getY(), this);
		}

		/*
		 * DRAW THINGS INTO EACH MODALITY
		 */
		if (gameLogic.getContext() > 1) {

			/*
			 * DRAW MOBS INTO EACH MODALITY AND THEM SHOTS
			 */
			List<GenericMob> copyMobs = new ArrayList<>();
			copyMobs.addAll(gameLogic.getMobs());
			for (GenericMob mob : copyMobs) {
				if (mob.isVisible()) {
					g.drawImage(mob.getImage(), mob.getX(), mob.getY(), this);

					/*
					 * DRAW MOB OR BOSS LIFE BAR
					 */
					mob.drawMobHp(g);
				}

				/*
				 * DRAW MOB's SHOT OR LASER
				 */
				List<Shot> mobShots = mob.GetShots();
				for (Shot shot : mobShots) {
					if (shot.isVisible())
						g.drawImage(shot.getImage(), shot.getX(), shot.getY(), this);
				}

				if (mob.getLaser() != null && mob.getLaser().isVisible()) {
					g.drawImage(mob.getLaser().getImage(), mob.getLaser().getX(), mob.getLaser().getY(), this);
					mob.setCollision(true);
				} else {
					mob.setCollision(false);
				}

			}

			/*
			 * DRAW ITEM DROPPED FROM MOBS
			 */
			for (GenericItem gi : gameLogic.getDrop_list()) {
				if (gi.isVisible())
					g.drawImage(gi.getImage(), gi.getX(), gi.getY(), this);
			}
			
			if(gameLogic.getMc().isBarrier())
				g.drawImage(gameLogic.getMc().getBarrier(),gameLogic.getMc().getX()-8,gameLogic.getMc().getY()-8,this);
		}

		/*
		 * DRAW HEAR OF MC
		 */
		if (gameLogic.getContext() != 1)
			gameLogic.getMc().drawHp(g, this);

		/*
		 * DRAW ITEM GRID INTO CHEST CONTEXT
		 */
		if (gameLogic.getContext() == 1)

		{
			gameLogic.getMc().drawStatistics(g, this);
			gameLogic.getMc().drawStorage(g, this);
			/*
			 * DRAW REMOVE DIALOG
			 */
			if (gameLogic.getMc().getShowRemoveDialog()) {
				gameLogic.getGd().showDialog(g, this, gameLogic.getMc().getRemoveDialogMessage(), 0);
			}
		}

		/*
		 * DRAW TIMER INTO SURVIVAL MODE
		 */
		if (gameLogic.getContext() == 3) {
			gameLogic.getGm().drawTimer(g, this);
		}

		/*
		 * DRAW MAIN CHARACTER
		 */
		if (gameLogic.getMc().isVisible() && gameLogic.getContext() != 1)
			g.drawImage(gameLogic.getMc().getImage(), gameLogic.getMc().getX(), gameLogic.getMc().getY(), this);
		

		/*
		 * DRAW PAUSE DIALOG
		 */
		if (gameLogic.getPause()) {
			gameLogic.getGd().showDialog(g, this, "MENU", 2);
		}

		g.setColor(Color.white);
	}

/// Adapter defining the KeyPressed and KeyReleased events for the main
/// character
	private class TAdapter extends KeyAdapter {

		@Override
		public void keyReleased(KeyEvent e) {
			if (!gameLogic.getPause())
				gameLogic.getMc().keyReleased(e);
		}

		@Override
		public void keyPressed(KeyEvent e) {
			gameLogic.gameKeyAdapter(e);
		}

	}

	/// Repaints all the objects when an action is performed
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (!gameLogic.getPause()) {

			gameLogic.getMc().move();
			gameLogic.getMc().shooting();
			gameLogic.getMc().updateShots();

			if (gameLogic.getContext() > 1) {
				gameLogic.updateMobs();
				gameLogic.checkGoal();
			}

			gameLogic.checkCollisions();

		}

		repaint();

	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if ((int) arg == 1) {
			change = true;
		}

	}
	
	public boolean getPause() {
		return gameLogic.getPause();
	}
	
	public void setPause(boolean flag) {
		gameLogic.setPause(flag);
	}

}
