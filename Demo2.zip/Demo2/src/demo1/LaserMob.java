package demo1;

import java.awt.Color;
import java.awt.Graphics;

public class LaserMob extends GenericMob {
	private Laser laser;
	private StrategyContextMob strategyContextMob; // strategy pattern context

	public LaserMob(int x, int y, int diff) {
		super(x, y);
		super.setMaxHp(super.generateStats(diff));
		collision = false;
		strategyContextMob = new StrategyContextMob();
		strategyContextMob.setMobStrategy(new ConcreteStrategyLaser());
		initLaserMob();
	}

	private void initLaserMob() {
		loadImage("src/images/mushroom.png");
		getImageDimensions();
	}

	public void update(int mc_x, int mc_y) {
		strategyContextMob.StrategyExecute(mc_x, mc_y, this);
	}

	public Laser getLaser() {
		return laser;
	}

	public void setLaser(Laser laser) {
		this.laser = laser;
	}
	
	@Override
	public void drawMobHp(Graphics g) {
		// TODO Auto-generated method stub
		int i;
		int step = getWidth() / getMaxHp();
		for (i = 0; i < getHp(); i++) {
			g.setColor(Color.white);
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
			g.setColor(Color.blue);
			g.fillRect(getX() + 1 + i * step, getY() + height + 6, getWidth() / getMaxHp() - 1, 9);
		}
		g.setColor(Color.white);
		for (; i < getMaxHp(); i++) {
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
		}
	}

}
