package demo1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class StalkerMob extends GenericMob {
	private StrategyContextMob strategyContextMob; // strategy pattern context
	private boolean canMoveX;
	private boolean canMoveY;
	private int old_x;
	private BufferedImage[] leftmovement = { StalkerSprite.getSprite(0, 0), StalkerSprite.getSprite(1, 0) };
	private BufferedImage[] rightmovement = { StalkerSprite.getSprite(0, 1), StalkerSprite.getSprite(1, 1) };	

	private Animation leftanimation = new Animation(leftmovement,10);
	private Animation rightanimation = new Animation(rightmovement,10);
	
	private Animation moveanimation = leftanimation;


	public StalkerMob(int x, int y, int diff) {
		super(x, y);
		old_x = x;
		super.setMaxHp(super.generateStats(diff));
		super.setAtk(super.generateStats(diff));
		setMappa(new ArrayList<MapElement>());
		initStalkerMob();
	}

	private void initStalkerMob() {

		setImage(moveanimation.getSprite());
		moveanimation.start();
		getImageDimensions();
		strategyContextMob = new StrategyContextMob();
		strategyContextMob.setMobStrategy(new ConcreteStrategyStalker());

	}
	
	@Override
	public BufferedImage getImage() {
		return moveanimation.getSprite();
	}
	
	private void changeDir() {
		if(old_x > getX()) {
			moveanimation = leftanimation;
			moveanimation.start();
		} else {
			moveanimation = rightanimation;
			moveanimation.start();
		}
		old_x = getX();
	}
	
	// update the position of the stalker mobs
	public void update(int mc_x, int mc_y) {
		strategyContextMob.StrategyExecute(mc_x, mc_y, this);
		changeDir();
		moveanimation.update();
	}

	public void moveY() {
		canMoveY = true;

		for (MapElement m : mappa) {
			if (m.getBounds().intersects(x, y + super.getSpd(), getBounds().getWidth(), getBounds().getHeight())) {
				canMoveY = false;
			}
		}
		if (canMoveY)
			y = getY() + super.getSpd();
	}

	public void moveX() {
		canMoveX = true;
		for (MapElement m : mappa) {
			if (m.getBounds().intersects(x + super.getSpd(), y, getBounds().getWidth(), getBounds().getHeight())) {
				canMoveX = false;
			}
		}
		if (canMoveX)
			x = getX() + super.getSpd();
	}
	@Override
	public void drawMobHp(Graphics g) {
		// TODO Auto-generated method stub
		int i;
		int step = getWidth() / getMaxHp();
		for (i = 0; i < getHp(); i++) {
			g.setColor(Color.white);
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
			g.setColor(Color.blue);
			g.fillRect(getX() + 1 + i * step, getY() + height + 6, getWidth() / getMaxHp() - 1, 9);
		}
		g.setColor(Color.white);
		for (; i < getMaxHp(); i++) {
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
		}

	}

}
