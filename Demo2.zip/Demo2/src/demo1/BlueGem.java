package demo1;

public class BlueGem extends GenericItem {

	public BlueGem(int x, int y) {
		super(x, y);
		loadImage("src/assets/blue.png");
		getImageDimensions();
		// TODO Auto-generated constructor stub
	}

	
	public int getType() {
		return 1;
	}
	
}
