package demo1;

public class GreenGem extends GenericItem{

	public GreenGem(int x, int y) {
		super(x, y);
		loadImage("src/assets/green.png");
		getImageDimensions();
		// TODO Auto-generated constructor stub
	}
	
	public int getType() {
		return 2;
	}

}
