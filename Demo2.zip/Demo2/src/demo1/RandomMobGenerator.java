package demo1;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomMobGenerator {

	private Random r;
	private List<MapElement> mappa;

	public RandomMobGenerator() {
		r = new Random();
		mappa = new ArrayList<MapElement>();
	}

	public void setMappa(List<MapElement> mappa) {
		this.mappa = mappa;
	}

	/// Initialize the mobs
	public List<GenericMob> getRandomMobs(int diff, boolean half) {

		List<GenericMob> mobs = new ArrayList<>();
		int numMobs = r.nextInt(5) + 1;

		for (int i = 0; i < numMobs; i++) {
			int type = r.nextInt(3) + 1;
			mobs.add(getRandomMob(type,half,diff));
		}

		return mobs;
	}
	
	public GenericMob getRandomBoss(int diff) {
		GenericMob gi = null;
		do{
			gi = new Boss(getRandomX(true),getRandomY(),diff);
		} while(checkCollision(gi.getBounds()));
		return gi;
	}

	// Function that checks if the blocks collide on the mob or character
	private boolean checkCollision(Rectangle rect) {
		for (MapElement mp : mappa) {
			Rectangle r = mp.getBounds();
			if (r.intersects(rect.getX(),rect.getY(),rect.getWidth()+3,rect.getHeight()+3)) {
				return true;
			}
		}
		return false;
	}

	public int getRandomX(boolean half) {
		Random r = new Random();
		int X;
		if (half)
			X = r.nextInt(250) + 400;			
		else
			X = r.nextInt(250) + 50;
		return X;
	}

	public int getRandomY() {
		Random r = new Random();
		int Y;
		do {
			Y = r.nextInt(450) + 50;
		} while (Y >= 225 && Y <= 325);
		return Y;
	}

	private GenericMob getRandomMob(int type, boolean half, int diff) {
		GenericMob mob = null;
		do {
			if (type == 1) {
				mob = new ShooterMob(getRandomX(half), getRandomY(), diff);
			} else if (type == 2) {
				mob = new StalkerMob(getRandomX(half), getRandomY(), diff);
			} else {
				mob = new LaserMob(getRandomX(half), getRandomY(), diff);
			}
		} while (checkCollision(mob.getBounds()));
		return mob;
	}

}
