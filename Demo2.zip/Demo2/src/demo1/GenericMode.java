package demo1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;

public class GenericMode extends Observable {
	
	private BufferedImage timer_frame;
	public int mode;
	Timer timer = new Timer();
	private static int difficulty = 1;
	private int remainTime;
	//MOB GENERATOR
	private boolean stop = false;
	private List<GenericMob> mobs;

	public GenericMode(int mode) {
		this.mode = mode;
		mobs = new ArrayList<GenericMob>();
		try {
			timer_frame = ImageIO.read(new File("src/assets/timer_frame.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void setMobs(List<GenericMob> mobs) {
		this.mobs = mobs;
	}
	
	public static void setDifficulty(int diff) {
		difficulty = diff;
	}

	public static int getDifficulty() {
		return difficulty;
	}
	public void increaseDifficulty() {
		difficulty += 1;
	}

	public int generateTime() {
		return difficulty * 10;
	}
	
	public void start() {
		if (mode == 3) {
			remainTime = generateTime();
			timer.scheduleAtFixedRate(new TimerTask() {
				@Override
				public void run() {
					if(!stop) {
						if (remainTime > 0) {
							remainTime -= 1;
						}
						if(remainTime != 0 && remainTime%5 == 0) {
							setChanged();
							notifyObservers(9);
						}
					}

				}

			}, 1000, 1000);

		}
	}
	
	public void stop() {
		stop = true;
	}
	public void restart() {
		stop = false;
	}

	public int getRemainTime() {
		return remainTime;
	}

	public boolean goal(int nMob) {
		switch (mode) {
		case 0:
			break;
		case 3: // Survive mode
			if (remainTime == 0 && mobs.size() == 0) {
				return true;
			}
			break;
		default: // Dungeon Mode and Boss Rush Mode
			if (nMob == 0) {
				return true;
			}
			break;
		}
		return false;

	}
	
	public void drawTimer(Graphics g, ImageObserver observer) {
		g.setColor(Color.BLACK);
		g.fillRect(350, 0, 100, 30);
		g.setColor(Color.WHITE);
		g.setFont(new Font("Helvetica", Font.BOLD, 20));
		g.drawString(convertTime(), 375, 22);
		g.setColor(Color.BLACK);
		g.drawImage(timer_frame,350,0,observer);
	}
	

	// Convert second into Standard TIMESTAMP
	private String convertTime() {
		int ts = remainTime;
		int min = (ts % 3600) / 60;
		int sec = ts % 60;
		return String.format("%02d:%02d", min, sec);
	}

}
