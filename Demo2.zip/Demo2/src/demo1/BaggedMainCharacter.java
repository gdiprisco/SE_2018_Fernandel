package demo1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;

public class BaggedMainCharacter extends MainCharacter implements Observer {

	private static final Color myWhite = new Color(179, 179, 179);
	private static final Color myBlue = new Color(136, 136, 255);
	private static final Color myYellow = new Color(252, 253, 118);
	private static final Color myPurple = new Color(161, 0, 159);
	private static final Color myBrown = new Color(149, 105, 66);

	private BufferedImage equipped_img, frame_img, heart_img;

	private List<GenericItem> storage;
	private GenericItem[] equipped;

	private int SELECTED_INDEX = 0;

	private boolean showRemoveDialog;
	
	private BufferedImage[] mcMove = {BigMcSprite.getSprite(0, 0), BigMcSprite.getSprite(1, 0), BigMcSprite.getSprite(2, 0)};
	private Animation chestAnimation = new Animation(this.mcMove,10);

	public BaggedMainCharacter() {
		this.storage = new ArrayList<GenericItem>();
		chestAnimation.start();
		
		this.showRemoveDialog = false;

		this.equipped = new GenericItem[3];

		for (int i = 0; i < 3; i++)
			this.equipped[i] = null;
		try {
			equipped_img = ImageIO.read(new File("src/assets/equip_img.png"));
			frame_img = ImageIO.read(new File("src/assets/frame.png"));
			heart_img = ImageIO.read(new File("src/assets/heart.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void setStorage(List<GenericItem> storage) {
		this.storage = storage;
	}

	public List<GenericItem> getStorage() {
		return this.storage;
	}

	public boolean checkCollisionItems(GenericItem item) {
		if (this.getBounds().intersects(item.getBounds())) {
			if (storage.size() < 70) {
				this.storage.add(item);
				item.setVisible(false);
				return true;
			} else {
				System.out.println("Lo zaino è peino");
				return false;
			}
		}
		return false;
	}
	
	// METOD TO DRAW HP ON SCREEN
	public void drawHp(Graphics g, ImageObserver observer) {
		int x = 50;
		int y = 2;
		for(int i = 0; i < getHp(); i++) {
			g.drawImage(heart_img,x,y,observer);
			x += heart_img.getWidth() + 5;
			if(i == 6) {
				x = 50;
				y += heart_img.getHeight()+3;
			}
		}
	}
	
	// METOD TO DRAW STATISTICS OF MAIN CHARACTER
	public void drawStatistics(Graphics g, ImageObserver observer) {
		chestAnimation.update();
		g.drawRect(50, 50, (46*7), (46*7));
		g.drawImage(chestAnimation.getSprite(), 115,115, observer);
		Font font = new Font("Helvetica", Font.ITALIC, 20);
		g.setFont(font);
		
		g.drawString("ATTACK", 50, 400);
		g.drawString("LIFE", 50, 450);
		g.drawString("SPEED", 50, 500);
		g.drawString("FIRERATE",50,550);
		
		g.drawString(":", 160, 400);
		g.drawString(":", 160, 450);
		g.drawString(":", 160, 500);
		g.drawString(":", 160, 550);
	
		if(getAtk() != 1)
			g.setColor(Color.RED);
		else
			g.setColor(Color.BLACK);
		g.drawString(String.valueOf(getAtk()), 175, 400);
		if(getHp() != 1)
			g.setColor(Color.RED);
		else
			g.setColor(Color.BLACK);
		g.drawString(String.valueOf(getMaxHp()),  175, 450);
		if(getSpd() != 2)
			g.setColor(Color.RED);
		else
			g.setColor(Color.BLACK);
		g.drawString(String.valueOf(getSpd()), 175, 500);
		if(this.getFireRate() != 50)
			g.setColor(Color.RED);
		else 
			g.setColor(Color.BLACK);
		g.drawString(String.valueOf(getFireRate()), 175, 550);
		
		g.setColor(Color.BLACK);

		drawRarityLegend(g);
		drawKeyLegend(g);
		
		font = new Font("Helvetica", Font.PLAIN, 12);
		g.setFont(font);

	}
	
	private void drawKeyLegend(Graphics g) {
		Font font = new Font("Helvetica", Font.BOLD, 12);
		g.setFont(font);
		int x_rect = 242;
		int y_rect = 500;
		g.drawRect(x_rect, y_rect, 130, 70);
		g.drawString("ENTER",x_rect+10,y_rect+20);
		g.drawString("R",x_rect+10,y_rect+40);
		g.drawString("ESC",x_rect+10,y_rect+60);
		g.drawString("=",x_rect+60,y_rect+20);
		g.drawString("=",x_rect+60,y_rect+40);
		g.drawString("=",x_rect+60,y_rect+60);
		g.drawString("Equip",x_rect+70,y_rect+20);
		g.drawString("Remove",x_rect+70,y_rect+40);
		g.drawString("Exit",x_rect+70,y_rect+60);
	}
	
	private void drawRarityLegend(Graphics g) {
		Font font = new Font("Helvetica", Font.BOLD, 12);
		g.setFont(font);
		int x_rect = 242;
		int y_rect = 380;
		g.drawRect(x_rect, y_rect, 130, 110);
		g.drawString("NORMAL",x_rect+10,y_rect+20);
		g.drawString("MAGIC",x_rect+10,y_rect+40);
		g.drawString("RARE",x_rect+10,y_rect+60);
		g.drawString("LEGENDARY",x_rect+10,y_rect+80);
		g.drawString("UNIQUE",x_rect+10,y_rect+100);
		g.drawString("1-3",x_rect+100,y_rect+20);
		g.drawString("1-5",x_rect+100,y_rect+40);
		g.drawString("1-7",x_rect+100,y_rect+60);
		g.drawString("1-9",x_rect+100,y_rect+80);
		g.drawString("1-11",x_rect+100,y_rect+100);

	}

	// METOD TO DRAW STORAGE OF MAIN CHARACTER
	public void drawStorage(Graphics g, ImageObserver o) {

		int X = 430;
		int Y = 50;
		int SELECTED_X = 430;
		int BLOCK_DIM = 46;
		int MAX_X = X + (BLOCK_DIM * 7);
		int MAX_Y = Y + (BLOCK_DIM * 10);
		g.setColor(myBrown);
		g.fillRect(X, Y, BLOCK_DIM * 7, MAX_Y);

		// DRAW INFO RACTANGLE
		g.setColor(Color.WHITE);
		g.drawRect(SELECTED_X, (BLOCK_DIM*11)+4, BLOCK_DIM * 7, 50);

		// DRAW GRID
		while (Y != MAX_Y) {
			// DRAW BOX
			g.drawRect(X, Y, BLOCK_DIM, BLOCK_DIM);
			X += BLOCK_DIM;
			if (X == MAX_X) {
				Y += BLOCK_DIM;
				X = 430;
			}
		}
		if (!storage.isEmpty()) {
			// DRAW ITEMS
			X = 430;
			Y = 50;
			int MARGIN = 1;
			int MARGIN2 = 2;
			for (int i = 0; i < storage.size(); i++) {

				// DRAW SINGLE ITEM
				switch (storage.get(i).getRarity()) {
				case 2:
					g.setColor(myWhite);
					g.fillRect(X + MARGIN, Y + MARGIN, BLOCK_DIM - MARGIN2, BLOCK_DIM - MARGIN2);
					break;
				case 3:
					g.setColor(myBlue);
					g.fillRect(X + MARGIN, Y + MARGIN, BLOCK_DIM - MARGIN2, BLOCK_DIM - MARGIN2);
					break;
				case 4:
					g.setColor(myYellow);
					g.fillRect(X + MARGIN, Y + MARGIN, BLOCK_DIM - MARGIN2, BLOCK_DIM - MARGIN2);
					break;
				case 5:
					g.setColor(myPurple);
					g.fillRect(X + MARGIN, Y + MARGIN, BLOCK_DIM - MARGIN2, BLOCK_DIM - MARGIN2);
					break;
				}
				
				g.drawImage(storage.get(i).getImage(), (X+23)-(storage.get(i).getWidth()/2), (Y+23)-(storage.get(i).getHeight()/2), o);

				// DRAW SELECTED ITEM ON THE BOTTOM
				if (i == SELECTED_INDEX) {
					g.drawImage(frame_img, X, Y, o);
					g.setColor(Color.WHITE);
					g.drawImage(storage.get(i).getImage(), SELECTED_X + 65, 520, o);
					Font font = new Font("Helvetica", Font.BOLD, 15);
					g.setFont(font);
					g.drawString(storage.get(i).toString(), SELECTED_X + 115, 540);
				}

				// DRAW EQUIP SIGN
				if (storage.get(i).getEquipped())
					g.drawImage(equipped_img, X + 35, Y, o);

				X += BLOCK_DIM;
				if (X == MAX_X) {
					Y += BLOCK_DIM;
					X = 430;
				}
			}
			g.setColor(Color.BLACK);
			g.drawRect(430, 50, BLOCK_DIM * 7, MAX_Y);
		} else {
			X = 430;
			Y = 50;
			g.drawImage(frame_img, X - 3, Y - 3, o);
			g.setColor(Color.BLACK);
		}
	}
	
	private void updateStats(int index) {
		switch (index) {
		case 0:
			if (this.equipped[index] != null)
				this.setAtk(this.equipped[index].getAttribute(index + 1) + 1);
			else
				this.setAtk(1);
			break;
		case 1:
			if (this.equipped[index] != null)
				this.setMaxHp(this.equipped[index].getAttribute(index + 1) + 1);
			else
				this.setMaxHp(1);
			break;
		case 2:
			if (this.equipped[index] != null)
				this.setSpd(this.equipped[index].getAttribute(index + 1) + 2);
			else
				this.setSpd(2);
			break;
		}
	}
	
	private void equipItem() {
		GenericItem gi = storage.get(SELECTED_INDEX);

		int index = gi.getType();

		if (this.equipped[index] != null) {
			if (gi.equals(this.equipped[index])) {
				this.equipped[index] = null;
				storage.get(storage.indexOf(gi)).setEquipped(false);
			} else {
				
				storage.get(storage.indexOf(this.equipped[index])).setEquipped(false);
				this.equipped[index] = gi;
				storage.get(storage.indexOf(gi)).setEquipped(true);
			}
		} else {
			this.equipped[index] = gi;
			storage.get(storage.indexOf(gi)).setEquipped(true);
		}
		updateStats(index);

	}

	private void removeItem() {
		if (!storage.isEmpty()) {
			if (!storage.get(SELECTED_INDEX).getEquipped()) {
				storage.remove(SELECTED_INDEX);
				if (SELECTED_INDEX > 0)
					SELECTED_INDEX--;
			} else
				System.out.println("YOU CAN'T DELETE EQUIPPED ITEM...");
		}
	}

	public void chestKeyPressed(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
			if (SELECTED_INDEX > 0)
				SELECTED_INDEX--;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
			if (SELECTED_INDEX < storage.size() - 1)
				SELECTED_INDEX++;
		}
		if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
			if ((SELECTED_INDEX - 7) > -1)
				SELECTED_INDEX -= 7;
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
			if ((SELECTED_INDEX + 7) < storage.size())
				SELECTED_INDEX += 7;
		}

		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			equipItem();
		}

		if (e.getKeyCode() == KeyEvent.VK_R) {
			this.showRemoveDialog = true;
		}

	}

	public boolean getShowRemoveDialog() {
		return showRemoveDialog;
	}

	public String getRemoveDialogMessage() {
		return "Do you want to remove this item ?";
	}

	public void setShowRemoveDialog(boolean showRemoveDialog) {
		this.showRemoveDialog = showRemoveDialog;
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if ((int) arg == 0) {
			removeItem();
		}
		this.showRemoveDialog = false;
	}
}
