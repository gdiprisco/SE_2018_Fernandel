package demo1;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import interfaces.GenerciMobIntarface;

public abstract class GenericMob extends GenericCharacter implements GenerciMobIntarface{

	
	private RandomItemGenerator rig;
	private boolean inGame = true;
	protected List<MapElement> mappa;
	protected boolean collision = true;

	public GenericMob(int x, int y) {
		super(x,y,1,1,1,50);
		mappa = new ArrayList<MapElement>();
		rig = new RandomItemGenerator();
	}

	public List<MapElement> getMappa() {
		return mappa;
	}
	
	public void setCollision(boolean collision) {
		this.collision = collision;
	}
	
	public boolean getCollision() {
		return this.collision;
	}

	public void setMappa(List<MapElement> mappa) {
		this.mappa = mappa;
	}
	
	public GenericItem dropItem(int difficulty) {
		return rig.getRandomItem(this.getX(), this.getY(), difficulty);
	}
	
	public boolean getDrop() {
		if(rig.getRandomDrop())
			return true;
		return false;
	}
	
	public void setInGame(boolean inGame) {
		this.inGame = inGame;
	}
	
	public boolean getInGame() {
		return inGame;
	}
	
	public List<Shot> GetShots() {
		return new ArrayList<Shot>();
	}
	
	public void update(int mc_x, int mc_y) {
		
	}
	
	public Laser getLaser() {
		return null;
	}
	
	public void setLaser(Laser laser) {
	}
	
	public boolean checkMobCollision(Rectangle character,int spd) {
		Rectangle m = getBounds();
		if(character.intersects(m)) {
			if((character.getCenterX()>= m.getMinX() && character.getCenterX()-spd<m.getMinX()) ||
			   (character.getCenterX()<= m.getMaxX() && character.getCenterX()+spd>m.getMinX()) ||
			   (character.getCenterY()>= m.getMaxY() && character.getCenterY()-spd<m.getMinY()) ||
			   (character.getCenterY()<= m.getMaxY() && character.getCenterY()+spd>m.getMinY()))
				return true;
		}

		return false;
	}
	
	public int generateStats(int diff) {
		int min=1+2*(diff-1);
		int max=1+3*diff;
		if(max > 10) max = 10;
		if (min > 9) min = 9;
		int randomNum = new Random().nextInt((max - min) + 1) + min;
		return randomNum;
	}
	
	
	
}
