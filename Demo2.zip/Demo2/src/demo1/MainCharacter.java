package demo1;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;

public class MainCharacter extends GenericCharacter{
	private List<Shot> shots;

	private int dx, dy;
	private boolean canMoveX;
	private boolean canMoveY;
	private boolean immunity = false;
	private boolean delay = false;
	private boolean barrier = false;
	private boolean changeRoom = true;
	private boolean flash = false;
	private boolean hitten = false;
	
	private BufferedImage barrier_img;

	// KEY FLAGS
	private boolean moveDown;
	private boolean moveLeft;
	private boolean moveRight;
	private boolean moveUp;
	private boolean shotDown;
	private boolean shotLeft;
	private boolean shotRight;
	private boolean shotUp;

	private Timer timer = new Timer();
	private int time = 1;
	private int lastShot = 0;
	private int spawnBarrier = 0;
	private int startFlashingChar = 0;

	// MOVING SPRITE
	protected BufferedImage[] walkingDown = { Sprite.getSprite(0, 0), Sprite.getSprite(2, 0) };
	private BufferedImage[] walkingLeft = { Sprite.getSprite(0, 1), Sprite.getSprite(2, 1) };
	private BufferedImage[] walkingRight = { Sprite.getSprite(0, 2), Sprite.getSprite(2, 2) };
	private BufferedImage[] walkingUp = { Sprite.getSprite(0, 3), Sprite.getSprite(2, 3) };

	// STANDING SPRITE
	private BufferedImage[] standingDown = { Sprite.getSprite(1, 0) };
	private BufferedImage[] standingLeft = { Sprite.getSprite(1, 1) };
	private BufferedImage[] standingRight = { Sprite.getSprite(1, 2) };
	private BufferedImage[] standingUp = { Sprite.getSprite(1, 3) };

	// ANIMATION TO WALK
	protected Animation walkDown = new Animation(walkingDown, 10);
	private Animation walkLeft = new Animation(walkingLeft, 10);
	private Animation walkRight = new Animation(walkingRight, 10);
	private Animation walkUp = new Animation(walkingUp, 10);

	// ANIMATION TO STAND
	private Animation standDown = new Animation(standingDown, 10);
	private Animation standLeft = new Animation(standingLeft, 10);
	private Animation standRight = new Animation(standingRight, 10);
	private Animation standUp = new Animation(standingUp, 10);

	// INITIAL STAND
	private Animation animation = standDown;

	// Constructor
	public MainCharacter() {
		super(375, 275, 1, 1, 2, 50);
		initMain();
		mappa = new ArrayList<MapElement>();
	}

	// Init main character
	private void initMain() {
		shots = new ArrayList<>();
		try {
			barrier_img = ImageIO.read(new File("src/assets/barrier.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setImage(animation.getSprite());
		getImageDimensions();
		start();

	}
	
	public BufferedImage getBarrier() {
		return this.barrier_img;
	}

	@Override
	public BufferedImage getImage() {
		return animation.getSprite();
	}

	// This method updates the position of the main character
	// based on the keys that have been pressed.
	// Also, it updates the sprites.
	public void move() {
		canMoveX = true;
		canMoveY = true;
		dx = 0;
		dy = 0;

		if (moveDown) {
			animation = walkDown;
			animation.start();
			dy += getSpd();
		}
		if (moveLeft) {
			animation = walkLeft;
			animation.start();
			dx += -getSpd();
		}
		if (moveRight) {
			animation = walkRight;
			animation.start();
			dx += getSpd();
		}
		if (moveUp) {
			animation = walkUp;
			animation.start();
			dy += -getSpd();
		}

		for (MapElement m : mappa) {
			if (m.getBounds().intersects(x + 8 + dx, y, getBounds().getWidth(), getBounds().getHeight())) {
				canMoveX = false;
			}
			if (m.getBounds().intersects(x + 8, y + dy, getBounds().getWidth(), getBounds().getHeight())) {
				canMoveY = false;
			}
		}

		if (canMoveX) {
			x += dx;
		}
		if (canMoveY) {
			y += dy;
		}
		animation.update();
	}
	
	public void shooting() {
		if(shotLeft) {
			fireLeft();
		}
		if(shotRight) {
			fireRight();
		}
		if(shotUp) {
			fireUp();
		}
		if(shotDown) {
			fireDown();
		}
	}

	public List<Shot> GetShots() {
		return shots;
	}

	/// Updates the position for the main character's shots
	public void updateShots() {
		for (int i = 0; i < shots.size(); i++) {
			Shot s = shots.get(i);
			int direction = s.getDirection();
			if (s.isVisible())
				switch (direction) {
				case 0:
					s.moveUp();
					break;
				case 1:
					s.moveDown();
					break;
				case 2:
					s.moveLeft();
					break;
				case 3:
					s.moveRight();
					break;
				}
			else
				shots.remove(i);
		}
	}

	// Key listener for the character
	public void keyPressed(KeyEvent e) {

		int key = e.getKeyCode();

		if (!immunity) {
			if (key == KeyEvent.VK_LEFT) {
				shotLeft = true;
			} else if (key == KeyEvent.VK_RIGHT) {
				shotRight = true;
			} else if (key == KeyEvent.VK_UP) {
				shotUp = true;
			} else if (key == KeyEvent.VK_DOWN) {
				shotDown = true;
			}
		}

		if (key == KeyEvent.VK_A) {
			moveLeft = true;
		}
		if (key == KeyEvent.VK_D) {
			moveRight = true;
		}
		if (key == KeyEvent.VK_W) {
			moveUp = true;
		}
		if (key == KeyEvent.VK_S) {
			moveDown = true;
		}
	}

	public void keyReleased(KeyEvent e) {

		int key = e.getKeyCode();

		if (key == KeyEvent.VK_A) {
			moveLeft = false;
			dx = 0;
			animation.stop();
			animation.reset();
			animation = standLeft;

		}

		if (key == KeyEvent.VK_D) {
			moveRight = false;
			dx = 0;
			animation.stop();
			animation.reset();
			animation = standRight;
		}

		if (key == KeyEvent.VK_W) {
			moveUp = false;
			dy = 0;
			animation.stop();
			animation.reset();
			animation = standUp;
		}

		if (key == KeyEvent.VK_S) {
			moveDown = false;
			dy = 0;
			animation.stop();
			animation.reset();
			animation = standDown;
		}

		if(key == KeyEvent.VK_UP) {
			shotUp = false;
		}
		if(key == KeyEvent.VK_DOWN) {
			shotDown = false;
		}
		if(key == KeyEvent.VK_LEFT) {
			shotLeft = false;
		}
		if(key == KeyEvent.VK_RIGHT) {
			shotRight = false;
		}

	}

	public void stopMc() {
		if (moveLeft) {
			moveLeft = false;
			dx = 0;
			animation.stop();
			animation.reset();
			animation = standLeft;
		}
		if (moveRight) {
			moveRight = false;
			dx = 0;
			animation.stop();
			animation.reset();
			animation = standRight;
		}
		if (moveUp) {
			moveUp = false;
			dy = 0;
			animation.stop();
			animation.reset();
			animation = standUp;
		}
		if (moveDown) {
			moveDown = false;
			dy = 0;
			animation.stop();
			animation.reset();
			animation = standDown;
		}
		shotUp = shotDown = shotLeft = shotRight = false;
	}

	// Methods to add a shot
	private void fireUp() {
		if (shotUp && !shotDown && !shotLeft && !shotRight) {
			if (time - lastShot >= getFireRate()) {
				shots.add(new Shot(x + width / 2, y - 10, 0, false));
				lastShot = time;
			}
			shotDown = shotLeft = shotRight = false;
		}

	}

	private void fireDown() {
		if (!shotUp && shotDown && !shotLeft && !shotRight) {
			if (time - lastShot >= getFireRate()) {
				shots.add(new Shot(x + width / 2, y + 10 + height, 1, false));
				lastShot = time;
			}
			shotUp = shotLeft = shotRight = false;
		}

	}

	private void fireLeft() {
		if (!shotUp && !shotDown && shotLeft && !shotRight) {
			if (time - lastShot >= getFireRate()) {
				shots.add(new Shot(x - 10, y + height / 2, 2, false));
				lastShot = time;
			}
			shotUp = shotDown = shotRight = false;
		}

	}

	private void fireRight() {
		if (!shotUp && !shotDown && !shotLeft && shotRight) {
			if (time - lastShot >= getFireRate()) {
				shots.add(new Shot(x + width, y + height / 2, 3, false));
				lastShot = time;
			}
			shotUp = shotDown = shotLeft = false;

		}
	}

	private void start() {
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				time += 1;
				defineBarrier();
				flashingChar();
			}

		}, 10, 10);
	}

	public void resetMC() {
		shots = new ArrayList<Shot>();
		x = 375;
		y = 275;
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(x + 8, y, 17, 30);
	}

	public void setImmunity(boolean immunity) {
		this.immunity = immunity;
	}

	public boolean getImmunity() {
		return this.immunity;
	}
	
	public boolean isBarrier() {
		return barrier;
	}

	public void setBarrier(boolean barrier) {
		this.barrier = barrier;
	}
	
	public void defineBarrier() {
		if(changeRoom) {
			barrier = true;
			immunity = true;
			delay=true;
			changeRoom = false;
			spawnBarrier = time;
		}
		if(barrier && time - spawnBarrier >= 250) {
			barrier = false;
		}
		if(delay && time - spawnBarrier >= 300) {
			immunity = false;
			delay=false;
		}
	}
	
	public void setChangeRoom() {
		changeRoom = true;
	}
	
	public void flashingChar() {
		if(hitten) {
			flash = true;
			immunity = true;
			hitten = false;
			startFlashingChar = time;
		}
	if(flash) {
		
		if(isVisible() && time % 3 == 0){
			setVisible(false);
		}
		else if(!isVisible() && time % 3 == 0){
			setVisible(true);
		}
		if(time - startFlashingChar >= 150) {
			flash = false;
			immunity = false;
			setVisible(true);
		}
	}
	}
	
	public void setHitten() {
		hitten = true;
	}

}
