package demo1;

import java.util.Random;

import interfaces.*;

public class ConcreteStrategyLaser implements MobStrategy {
	private GenericMob mob;

	private String images[] = { "laserUp", "laserDown", "laserLeft", "laserRight" };
	private int laserX;
	private int laserY;
	private int firingLaser;
	private int laserMobStop = 300;

	private boolean canMoveX = false;
	private boolean canMoveY = false;
	private int movementCounter = 50;
	private int movementRandom;

	public void update(int mc_x, int mc_y, GenericMob mob) {
		this.mob = mob;


		// if mc x or y are defined between mob x or y, the mob stops and prepares to
		// shoot the beam
		// if the mob started charging the beam, it won't move (laseroMobStop < 300)
		if ((mc_x > mob.getX() && mc_x < mob.getX() + mob.getWidth())
				|| (mc_y > mob.getY() && mc_y < mob.getY() + mob.getHeight()) || laserMobStop < 300) {
			// mc up of the mob
			if (mc_y < mob.getY() && mc_x > mob.getX() && mc_x < mob.getX() + mob.getWidth() && laserMobStop == 300) {
				firingLaser = 0;
				laserX = mob.getX() + (mob.getWidth()/2)-7;
				laserY = mob.getY() - 800;
			}
			// mc down of the mob
			else if (mc_y > mob.getY() && mc_x > mob.getX() && mc_x < mob.getX() + mob.getWidth()
					&& laserMobStop == 300) {
				firingLaser = 1;
				laserX = mob.getX() + (mob.getWidth() / 2) - 7; 
				laserY = mob.getY() + mob.getHeight();
			}
			// mc left of the mob
			else if (mc_x < mob.getX() && mc_y > mob.getY() && mc_y < mob.getY() + mob.getHeight()
					&& laserMobStop == 300) {
				firingLaser = 2;
				laserX = mob.getX() - 800;
				laserY = mob.getY() + (int)(mob.getHeight() / 2);
			}
			// mc right of the mob
			else if (mc_x > mob.getX() && mc_y > mob.getY() && mc_y < mob.getY() + mob.getHeight()
					&& laserMobStop == 300) {
				firingLaser = 3;

				laserX = mob.getX() + mob.getWidth();
				laserY = mob.getY() + (int)(mob.getHeight() / 2);
			}

			laserMobStop--;

			if (laserMobStop == 200) {
				
				if(laserX==0) {
					laserX = mob.getX();
				}
				if(laserY==0) {
					laserY = mob.getY();
				}
				mob.setLaser(new Laser(laserX, laserY, images[firingLaser])); // uploads new laser in the mob position
				mob.getLaser().setVisible(true);

			} else if (laserMobStop == 0) {
				mob.setLaser(null);
				laserMobStop = 300;
			}

		} else if (laserMobStop == 300) {
			setMovement();
		}
	}

	// sets a random movement for the mob
	private void setMovement() {
		if (movementCounter == 50)
			movementRandom = new Random().nextInt(4);

		int dx = 0;
		int dy = 0;
		canMoveX = true;
		canMoveY = true;

		switch (movementRandom) {
		case 0:
			dy = -mob.getSpd();
			break;
		case 1:
			dy = mob.getSpd();
			break;
		case 2:
			dx = -mob.getSpd();
			break;
		case 3:
			dx = mob.getSpd();
			break;
		}

		for (MapElement m : mob.mappa) {
			if (m.getBounds().intersects(mob.x + dx, mob.y, mob.getBounds().getWidth(), mob.getBounds().getHeight())) {
				canMoveX = false;
			}
			if (m.getBounds().intersects(mob.x, mob.y + dy, mob.getBounds().getWidth(), mob.getBounds().getHeight())) {
				canMoveY = false;
			}
		}

		if (canMoveX)
			mob.setX(mob.x + dx);
		if (canMoveY)
			mob.setY(mob.y + dy);

		movementCounter--;
		if (movementCounter == 0)
			movementCounter = 50;
	}
}
