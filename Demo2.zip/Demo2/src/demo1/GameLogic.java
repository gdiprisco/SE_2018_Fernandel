package demo1;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class GameLogic extends Observable implements Observer {

	// VARIABLE OF CONTEXT AND MAPS
	private MapGenerator mg;
	private List<MapElement> map;
	private List<GenericItem> drop_list;
	/*
	 * CONTEXT LIST: 0 = MAIN ROOM; 1 = CHEST MENU; 2 = FIRST MODALITY (DUNGEON)
	 */
	private int context;

	private BaggedMainCharacter mc; // player's character
	private List<GenericMob> mobs; // list of enemies to defeat

	private boolean death; // flag to see if the player died

	// GENERIC DIALOG
	private GenericDialog gd;

	// MOB GENERATOR
	private RandomMobGenerator rmb;

	// GENERIC MODALITY
	private GenericMode gm;
	private boolean door = false;
	private boolean on_door = false;
	private Rectangle central_box;

	private boolean pause;


	/// Initialize the window, the main character and the mobsS
	public GameLogic() {

		// INSTANCE ALL VARIABLES
		map = new ArrayList<MapElement>();
		drop_list = new ArrayList<GenericItem>();
		rmb = new RandomMobGenerator();
		mc = new BaggedMainCharacter();
		central_box = new Rectangle();
		central_box.setBounds((int) mc.getBounds().getX() - 20, (int) mc.getBounds().getY() - 20,
				(int) mc.getBounds().getWidth() + 15, (int) mc.getBounds().getHeight() + 15);
		gd = new GenericDialog();
		mg = new MapGenerator();

		// ADD OBSERVERS
		gd.addObserver(mc);
		gd.addObserver(this);
		mc.addObserver(this);

		// SET MAIN CONTEXT
		context = 0; // MAIN ROOM
		setChanged();
		notifyObservers(1);

		// TEMPORANEA PER I TESTS
		addEquip();

		pause = false;

	}

	// TEMPORANEA
	private void addEquip() {
		for (int i = 0; i < 25; i++) {
			ShooterMob m = new ShooterMob(0, 0, 1);
			mc.getStorage().add(m.dropItem(45));
		}
	}

	// Initialize the Map Generator
	public void initMap() {
		map = new ArrayList<MapElement>();
		drop_list = new ArrayList<GenericItem>();
		mobs = new ArrayList<GenericMob>();
		mc.resetMC();

		mg.addNotStackable(central_box);

		gm = new GenericMode(context);
		gm.addObserver(this);

		door = false;

		switch (context) {
		case 0:
			GenericMode.setDifficulty(1);
			door = false;
			map = mg.getMainRoomMap();
			map.addAll(mg.getBorders());
			break;
		case 1:
			map = mg.getChestMap();
			break;
		case 2: // DUNGEON
			map = mg.getRandomMap();
			map.addAll(mg.getBorders());
			rmb.setMappa(map);
			if (GenericMode.getDifficulty() != 0 && GenericMode.getDifficulty() % 5 == 0) {
				mobs = new ArrayList<GenericMob>();
				mobs.add(rmb.getRandomBoss(GenericMode.getDifficulty()));
			}

			else {
				mobs = rmb.getRandomMobs(GenericMode.getDifficulty(), mc.getX() < 400);
			}
			gm.start();
			break;
		case 3: // SURVIVAL
			map = mg.getRandomMap();
			map.addAll(mg.getBorders());
			rmb.setMappa(map);
			mobs = rmb.getRandomMobs(GenericMode.getDifficulty(), mc.getX() < 400);
			gm.setMobs(mobs);
			gm.start();
			break;

		case 4: // BOSS RUSH

			mobs = new ArrayList<GenericMob>();
			map = mg.getRandomMap();
			map.addAll(mg.getBorders());
			rmb.setMappa(map);
			mobs.add(rmb.getRandomBoss(GenericMode.getDifficulty()));
			gm.start();
			break;
		}

		List<GenericMob> copyMobs = new ArrayList<GenericMob>();
		copyMobs.addAll(mobs);
		for (GenericMob m : copyMobs)
			m.setMappa(map);

		mc.setMappa(map);
	}

	public void addNewMob() {
		if (mobs != null) {
			rmb = new RandomMobGenerator();
			rmb.setMappa(map);
			List<GenericMob> newMobs = rmb.getRandomMobs(GenericMode.getDifficulty(), mc.getX() < 400);
			for (GenericMob m : newMobs) {
				m.setMappa(map);
			}
			mobs.addAll(newMobs);
		}
	}


	public void checkGoal() {

		if (mobs != null) {
			int cont = 0;
			for (GenericMob m : mobs) {
				if (m.isVisible())
					cont++;
			}
			boolean goal = gm.goal(cont);

			if (goal) {
				// SE SURVIVE
				if (context == 3) {
					for (int i = 0; i < mobs.size(); i++) {
						mobs.remove(i);
					}
				}

				if (!door) {
					map.add(0, mg.getDoor(drop_list,(mc.getX()<400)));
					door = true;
				}

			}
		}
	}

	private void hitLogic(Shot s) {
		if (!mc.getImmunity()) {
			if (s != null)
				s.setVisible(false);
			
			
			mc.setHp(mc.getHp() - 1);
			if (mc.getHp() == 0) {
				death = true;
				mc.setHp(mc.getMaxHp());
			} else {
				mc.setHitten();

			}
		}
		
	}

	/// Updates the position for the mobs
	public void updateMobs() {
		if (mobs.isEmpty()) {
			return;
		}
		for (int i = 0; i < mobs.size(); i++) {
			GenericMob m = mobs.get(i);

			if (m.isVisible()) {
				m.update(mc.getX(), mc.getY());
			} else {
				if (!m.GetShots().isEmpty())
					m.update(mc.getX(), mc.getY());
				else
					mobs.remove(i);
			}

		}
	}

	/// Checks collisions between the main character, the mobs and the shots
	public void checkCollisions() {
		Rectangle r1 = mc.getBounds();

		// CHECK COLLISION BETWEEN MC AND ENEMIES
		if (!death && context > 1) {
			List<GenericMob> copyMobs = new ArrayList<GenericMob>();
			copyMobs.addAll(mobs);
			for (GenericMob mob : copyMobs) {

				// COLLISION WITH MOB
				if (mob.checkMobCollision(r1, mc.getSpd()) && mob.isVisible()) {
					hitLogic(null);
				}
				// COLLISION OF MOB'S SHOT
				List<Shot> mobShots = mob.GetShots();
				for (Shot shot : mobShots) {
					Rectangle r3 = shot.getBounds();

					// COLLISION WITH MOB'S SHOT AND MC
					if (r3.intersects(r1)) {
						hitLogic(shot);
					}

					// CHECK COLLISON BETWEEN MOB SHOTS AND WALLS
					for (MapElement r : map) {
						if (r3.intersects(r.getBounds())) {
							shot.setVisible(false);
						}
					}
				}

				if (mob.getCollision()) {
					if (mob.getLaser() != null && mob.getLaser().isVisible()) {
						if (r1.intersects(mob.getLaser().getBounds())) {
							hitLogic(null);
						}
					}
				}

			}
		}

		// CHECK COLLISION BETWEEN OUR SHOTS AND OBSTACLE (WALLS, ENEMIES...)
		List<Shot> shots = mc.GetShots();
		for (Shot shot : shots) {
			Rectangle r3 = shot.getBounds();
			if (!death) {
				if (context > 1) {
					List<GenericMob> copyMobs = new ArrayList<GenericMob>();
					copyMobs.addAll(mobs);
					for (GenericMob mob : copyMobs) {
						if (mob.isVisible()) {
							Rectangle r2 = mob.getBounds();
							// MOB LOGIC FOR DODGE (ONLY DOWN/RIGHT)
							if (r3.getY() + 10 >= r2.getY() && r3.getY() <= r2.getY() + mob.height + 10) {

								if (shot.getDirection() == 3 && r3.getX() < r2.getX() + 50)
									mob.moveY();
								else if (shot.getDirection() == 2 && r3.getX() > r2.getX() - 50)
									mob.moveY();
							} else if (r3.getX() + 10 >= r2.getX() && r3.getX() <= r2.getX() + mob.height + 10) {
								if (shot.getDirection() == 0 && r3.getY() > r2.getY() + 50)
									mob.moveX();
								else if (shot.getDirection() == 1 && r3.getY() < r2.getY() - 50)
									mob.moveX();
							}
							//

							if (r3.intersects(r2)) {
								shot.setVisible(false);
								mob.setHp(mob.getHp() - mc.getAtk());
								if (mob.getHp() <= 0) {
									mob.setVisible(false);
									mob.setInGame(false);
									if (mob.getDrop())
										drop_list.add(mob.dropItem(GenericMode.getDifficulty()));

								}

							}
						}
					}
				}
				for (MapElement r : map) {
					if (r3.intersects(r.getBounds())) {
						shot.setVisible(false);
					}
				}
			}
		}

		// CHECK COLLISION BETWEEN MC AND ITEMS
		for (GenericItem gi : drop_list) {
			if (gi.isVisible())
				mc.checkCollisionItems(gi);
		}

		// CHECK COLLISION WITH DOORS & CHEST
		if (context == 0 && map.size() > 3) {
			if (map.get(0).checkInFrontOfCollision(r1, mc.getSpd())) {
				map.get(0).loadImage("src/assets/doorbox_40x40_opened.png");
			} else {
				map.get(0).loadImage("src/assets/doorbox_40x40.png");
			}
			if (map.get(1).checkInFrontOfCollision(r1, mc.getSpd())) {
				map.get(1).loadImage("src/assets/doorbox_40x40_opened.png");
			} else {
				map.get(1).loadImage("src/assets/doorbox_40x40.png");
			}
			if (map.get(4).checkInFrontOfCollision(r1, mc.getSpd())) {
				map.get(4).loadImage("src/assets/doorbox_40x40_opened.png");
			} else {
				map.get(4).loadImage("src/assets/doorbox_40x40.png");
			}

			if (map.get(2).getBounds().intersects(r1.getX() + mc.getSpd(), r1.getY(), r1.getWidth(), r1.getHeight())||
				map.get(2).getBounds().intersects(r1.getX() - mc.getSpd(), r1.getY(), r1.getWidth(), r1.getHeight())||
				map.get(2).getBounds().intersects(r1.getX(), r1.getY() + mc.getSpd(), r1.getWidth(), r1.getHeight())||
				map.get(2).getBounds().intersects(r1.getX(), r1.getY() - mc.getSpd(), r1.getWidth(), r1.getHeight())) {
				map.get(3).setVisible(true);
			} else {
				map.get(3).setVisible(false);
			}
		}

		if (door) {
			if (map.get(0).getBounds().intersects(r1.getX() + mc.getSpd(), r1.getY() + mc.getSpd(), r1.getWidth(),
					r1.getHeight())
					|| map.get(0).getBounds().intersects(r1.getX() - mc.getSpd(), r1.getY() - mc.getSpd(),
							r1.getWidth(), r1.getHeight())) {
				map.get(0).loadImage("src/assets/trapdoor_40x40.png");
				on_door = true;
			} else {
				map.get(0).loadImage("src/assets/trapdoor_40x40_closed.png");
				on_door = false;
			}
		}
	}

	public void gameKeyAdapter(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			if (context != 1) {
				if (!pause) {
					pause = true;
					mc.stopMc();
				} else
					pause = false;
			} else if (context == 1) {
				context = 0;
				setChanged();
				notifyObservers(1);
			}
		}

		if (pause) {
			gd.dialogKeyPressed(e);
			gm.stop();
		} else {
			if (!death && context != 1)
				gm.restart();
			mc.keyPressed(e);

			/*
			 * ADD KEY ACTION NEAR THE CHEST
			 */
			if (context == 0 && e.getKeyCode() == KeyEvent.VK_E) {
				if (map.get(3).isVisible()) {
					mc.setChangeRoom();
					context = 1;
					setChanged();
					notifyObservers(1);
				} else if (map.get(0).checkInFrontOfCollision(mc.getBounds(), mc.getSpd())) {
					mc.setChangeRoom();
					context = 2;
					setChanged();
					notifyObservers(1);
//					spawnImmunity();
				} else if (map.get(1).checkInFrontOfCollision(mc.getBounds(), mc.getSpd())) {
					mc.setChangeRoom();
					context = 3;
					setChanged();
					notifyObservers(1);
//					spawnImmunity();

				} else if ((map.get(4).checkInFrontOfCollision(mc.getBounds(), mc.getSpd()))) {
					mc.setChangeRoom();
					context = 4;
					setChanged();
					notifyObservers(1);
//					spawnImmunity();
				}
			}

			/*
			 * ADD KEY ACTION INTO CHEST CONTEXT
			 */
			if (context == 1) {
				if (mc.getShowRemoveDialog()) {
					gd.dialogKeyPressed(e);
				} else {
					mc.chestKeyPressed(e);
				}
			}
			if (context > 1) {
				if (e.getKeyCode() == KeyEvent.VK_E && door) {
					if (on_door) {
						on_door = false;
						mc.setChangeRoom();
						gm.increaseDifficulty();
						System.out.print("DIFFICOLTA' = " + String.valueOf(GenericMode.getDifficulty()) + "\n");
						setChanged();
						notifyObservers(1);
					}
				}
			}

			if (death) {
				gd.dialogKeyPressed(e);
			}
		}

	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if ((int) arg == 3) {
			death = false;
			context = 0;
			setChanged();
			notifyObservers(1);
		}

		else if ((int) arg == 9) {
			this.addNewMob();
		}

		if ((int) arg == 5) {
			pause = false;
		} else if ((int) arg == 6) {
			pause = false;
			if (context == 0) {
				System.exit(0);
			} else {
				context = 0;
				mc.setHp(mc.getMaxHp());
				setChanged();
				notifyObservers(1);
			}
		}

	}

	public MapGenerator getMg() {
		return mg;
	}

	public void setMg(MapGenerator mg) {
		this.mg = mg;
	}

	public List<MapElement> getMap() {
		return map;
	}

	public void setMap(List<MapElement> map) {
		this.map = map;
	}

	public List<GenericItem> getDrop_list() {
		return drop_list;
	}

	public void setDrop_list(List<GenericItem> drop_list) {
		this.drop_list = drop_list;
	}

	public int getContext() {
		return context;
	}

	public void setContext(int context) {
		this.context = context;
	}

	public BaggedMainCharacter getMc() {
		return mc;
	}

	public void setMc(BaggedMainCharacter mc) {
		this.mc = mc;
	}

	public List<GenericMob> getMobs() {
		return mobs;
	}

	public void setMobs(List<GenericMob> mobs) {
		this.mobs = mobs;
	}

	public boolean isDeath() {
		return death;
	}

	public void setDeath(boolean death) {
		this.death = death;
	}

	public GenericDialog getGd() {
		return gd;
	}

	public void setGd(GenericDialog gd) {
		this.gd = gd;
	}

	public RandomMobGenerator getRmb() {
		return rmb;
	}

	public void setRmb(RandomMobGenerator rmb) {
		this.rmb = rmb;
	}

	public GenericMode getGm() {
		return gm;
	}

	public void setGm(GenericMode gm) {
		this.gm = gm;
	}

	public boolean isDoor() {
		return door;
	}

	public void setDoor(boolean door) {
		this.door = door;
	}

	public boolean getPause() {
		return this.pause;
	}

	public void setPause(boolean pause) {
		this.pause = pause;
	}

}
