package demo1;

import java.awt.Rectangle;

public class MapElement extends GenericElement {
	
	public MapElement(int x, int y, String image_name) {
		super(x, y);
		// TODO Auto-generated constructor stub
		loadImage(image_name);
		getImageDimensions();
	}
	
	public boolean checkInFrontOfCollision(Rectangle character, int speed) {
		int MARGIN = 10;
		if (getBounds().intersects(character.getX(), character.getY()-speed, character.getWidth(), character.getHeight())) {
			if ((character.getCenterX() > getBounds().getX() + MARGIN
					&& character.getCenterX() < getBounds().getX() + getBounds().getWidth() - MARGIN)
					&& character.getCenterY() > getBounds().getY() + getBounds().getHeight() - MARGIN) {
				return true;
			}
		}
		return false;
	}

}
