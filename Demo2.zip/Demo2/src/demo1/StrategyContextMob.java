package demo1;
import interfaces.*;

public class StrategyContextMob {
	
	private MobStrategy mobStrategy;
	
	
	public void setMobStrategy(MobStrategy ms) {
		mobStrategy = ms;
	}
	
	public void StrategyExecute(int mc_x, int mc_y, GenericMob mob) {
		mobStrategy.update(mc_x, mc_y, mob);
	}
}
