package demo1;

import java.util.Random;

public class RandomItemGenerator {
	
	// GENERIC MINIMUM FOR ALL VALUES
	private static final int MIN = 1;
	
	// MAXIMUM RANGE FOR ATTRUBUTE TYPE
	private static final int MAX_ATTRIBUTE_TYPE = 3;
	
	private Random r = new Random();
	
	// Calculate random rarity 
	// RARITY -> 1 = NORMAL, 2 = MAGIC, 3 = RARE, 4 = LEGGENDARY, 5 = UNIQUE;
	private int getRandomRarity(int difficulty) {
		int a = 1;
		int b = 2+(difficulty/10);
		
		double weightRand = 1.0 - Math.sqrt(r.nextDouble());
		
		int value = (int) Math.floor((b-a) * weightRand) + a;
		if(value >= b)
			return a;
		
		return value;
	}

	// Calculate random value for the attribute	
	private int getRandomAttributeValue(int rarity) {
		
		int a = 1;					// lower bound, inclusive
		int b = 4+(2*(rarity-1)); // upper bound, exclusive
		
		double weightRand = 1.0 - Math.sqrt(r.nextDouble());
		
		int value = (int) Math.floor((b-a) * weightRand) + a;
		if(value >= b)
			return a;
		
		return value;
	}
	
	// Calculate random type of attribute
	// ATTR_TYPE -> 1 = ATTACK, 2 = ARMOR, 3 = AMULETS
	private int getRandomAttributeType() {
		return r.nextInt((MAX_ATTRIBUTE_TYPE - MIN) + 1) + MIN;
	}
	
	public GenericItem getRandomItem(int x, int y, int difficulty) {
		int rarity = getRandomRarity(difficulty);
		int attribute_type = getRandomAttributeType();
		int attribute_value = getRandomAttributeValue(rarity);

		
 		GenericItem gi = null;
 		
		if(attribute_type == 1)
			gi = new RedGem(x,y);
		else if(attribute_type == 2)
			gi = new BlueGem(x,y);
		else if(attribute_type == 3)
			gi = new GreenGem(x,y);
		
		gi.setRarity(rarity);
		gi.addAttribute(attribute_type, attribute_value);
		return gi;
	}
	
	public boolean getRandomDrop() {
		int MAX = 10;
		int chance = r.nextInt(((MAX - MIN) + 1) + MIN);
		if(chance <= 2) {
			return true;
		}
		return false;
	}
	
	

}
