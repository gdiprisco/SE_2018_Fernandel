package demo1;

import interfaces.*;

public class ConcreteStrategyStalker implements MobStrategy{
	
	private GenericMob mob;
	private boolean canMoveX;
	private boolean canMoveY;

	private void move(int mc_x, int mc_y) {
		int dx = 0;
		int dy = 0;
		canMoveX = true;
		canMoveY = true;

		if (mob.getY() - mc_y > 0) {
			dy = -mob.getSpd();
		}
		if (mob.getY() - mc_y < 0) {
			dy = mob.getSpd();
		}
		if (mob.getX() - mc_x > 0) {
			dx = -mob.getSpd();
		}
		if (mob.getX() - mc_x < 0) {
			dx = mob.getSpd();
		}

		for (MapElement m : mob.mappa) {
			if (m.getBounds().intersects(mob.getX() + dx, mob.getY(), mob.getBounds().getWidth(), mob.getBounds().getHeight())) {
				canMoveX = false;
			}
			if (m.getBounds().intersects(mob.getX(), mob.getY() + dy, mob.getBounds().getWidth(), mob.getBounds().getHeight())) {
				canMoveY = false;
			}
		}

		if (canMoveX)
			mob.setX(mob.getX() + dx);
		if (canMoveY)
			mob.setY(mob.getY() + dy);

	}
	
	//update the position of the stalker mobs
	public void update(int mc_x, int mc_y, GenericMob mob) {
		this.mob=mob;
		move(mc_x,mc_y);
	}
	
}
