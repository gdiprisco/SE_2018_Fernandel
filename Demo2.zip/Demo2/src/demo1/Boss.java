package demo1;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import interfaces.*;


public class Boss extends GenericMob{

	private List<Shot> shots;
	private Laser laser;
	private StrategyContextMob strategyContextMob;
	private List<MobStrategy> mobStrategies = new ArrayList<>();
	private boolean modes[] = {false,false,false};
//	private boolean second_bar = false;
//	private int second_maxHp = 0;

	public Boss(int x,int y,int diff) {
		super(x, y);
		int val = 20; //default val for lifebar
//		if(diff > 14) {
//			val = 24;
//			second_maxHp = val * 15; //maximum life in bar when diff is greater then 14
//			second_bar = true;
//		}else {
//			while((720/diff) * diff != 720) { //if is not divisible for diff
//				diff--;
//			}
//			while((720/(val*diff))*(val*diff) != 720) { //if is divisible but with val not
//				val--;
//			}
//		}
//	
		
		super.setMaxHp(val*diff);
		
//		System.out.println("vita" + super.getMaxHp());
//		System.out.println("vita che entra" + second_maxHp);
		
		super.setAtk(super.generateStats(diff));
		//super.setSpd(super.generateStats(diff));
		shots = new ArrayList<>();
		//init list of ConcreteStrategy
		initStrategyList(diff);
		//init actual ContextStrategy
		strategyContextMob = new StrategyContextMob();
		collision = false;
		initBoss();
	}
	
	@Override
	public int generateStats(int diff) {
		int min=1+2*(diff-1);
		int max=1+5*diff;
		if(max > 10) max = 10;
		if (min > 9) min = 9;
		int randomNum = new Random().nextInt((max - min) + 1) + min;
		return randomNum;
	}
	
	
	private void initStrategyList(int diff) {
		mobStrategies.add(new ConcreteStrategyStalker());
		mobStrategies.add(new ConcreteStrategyShooter());
		((ConcreteStrategyShooter)mobStrategies.get(1)).setFireRate(200-(20*diff));
		mobStrategies.add(new ConcreteStrategyLaser());
	}
	
	private void initBoss() {
		loadImage("src/images/greenmushroom.png");
		getImageDimensions();
	}
	
	/*private boolean control() {
		return super.getHp() > (70*super.getMaxHp())/100;	
	}*/
	
		/*if(control() && !active) {
			active= true;
			Timer t= new Timer();
			t.scheduleAtFixedRate(new TimerTask() {
	              @Override
	              public void run() {
	            	x=coordX[state];
	      			y=coordY[state];
	      			if (state < 3)
	      				state++;
	      			else state = 0;
	      			if(!control()) return;
	              }

	          }, 0, 1000);
			
		}*/
	

	public List<Shot> GetShots() {
		return shots;
	}
	
	public Laser getLaser() {
		return laser;

	}
	
	public void setLaser(Laser laser) {
		this.laser = laser;
	}
	
	public void update(int mc_x, int mc_y) {
		//first stage of the boss
		if(!modes[0] && super.getHp() > (70*super.getMaxHp())/100) {
			int randomNum = new Random().nextInt(mobStrategies.size());
			strategyContextMob.setMobStrategy(mobStrategies.get(randomNum));
			mobStrategies.remove(randomNum);
			modes[0] = true;
		}
		//second stage of the boss
		else if(!modes[1] && super.getHp() > (40*super.getMaxHp())/100 && super.getHp() < (70*super.getMaxHp())/100) {
			int randomNum = new Random().nextInt(mobStrategies.size());
			shots = new ArrayList<>();
			setLaser(null);
			strategyContextMob.setMobStrategy(mobStrategies.get(randomNum));
			mobStrategies.remove(randomNum);
			modes[1] = true;
		}
		//third stage of the boss
		else if(!modes[2] && super.getHp() < (40*super.getMaxHp())/100) {
			int randomNum = new Random().nextInt(mobStrategies.size());
			shots = new ArrayList<>();
			setLaser(null);
			strategyContextMob.setMobStrategy(mobStrategies.get(randomNum));
			mobStrategies.remove(randomNum);
			modes[2] = true;
		}
		strategyContextMob.StrategyExecute(mc_x, mc_y, this);
	}

//	@Override
//	public void drawMobHp(Graphics g) {
//		// TODO Auto-generated method stub
//		int i;
//		int step;
//		if(second_bar) { //if is true print at first the red bar then the MAGENTA on the red
//			step = 720 / second_maxHp;
//			g.setColor(Color.black);
//			g.fillRect(40, 575, 720, 15);
//			for (i = 0; i < ((this.getHp() <= second_maxHp)?this.getHp():second_maxHp); i++) {
//				g.setColor(Color.red);
//				g.fillRect(40 + i*step, 575, step-1, 15);
////				System.out.println(40 + i*step);
//			}
//			for (i = 0; i < this.getHp()-second_maxHp; i++) {
//				g.setColor(Color.magenta);
//				g.fillRect(40 + i*step, 575, step-1, 15);
//			}
//		}else {
//			step = 720 / this.getMaxHp();
//			g.setColor(Color.black);
//			g.fillRect(40, 575, 720, 15);
//			for (i = 0; i < this.getHp(); i++) {
//				g.setColor(Color.red);
//				g.fillRect(40 + i*step, 575, step-1, 15);
//			}
//		}
//		
////		if(step*this.getMaxHp() < 720) {
////			maxWidth = step*this.getMaxHp();
////		}
//
//
//		g.setColor(Color.yellow);
//		g.drawRect(39, 575,720, 14);
//		Font font = new Font("Helvetica", Font.BOLD, 20);
//		g.setFont(font);
//		g.setColor(Color.WHITE);
//		FontMetrics metrics = g.getFontMetrics(font);
//		g.drawString("BOSS", (40 + (720 - metrics.stringWidth("BOSS")) / 2), 590);
//	}
	
	@Override
	public void drawMobHp(Graphics g) {
		// TODO Auto-generated method stub
		int perc_life = ((getHp()*100)/getMaxHp())+1;
		g.setColor(Color.black);
		g.fillRect(50, 575, 700, 18);
			g.setColor(Color.red);
			if(perc_life > 100)
				perc_life = 100;
			g.fillRect(50, 575, 700-(7*(100-(perc_life))), 18);
		g.setColor(Color.yellow);
		g.drawRect(50, 575,700, 18);
		Font font = new Font("Helvetica", Font.BOLD, 15);
		g.setFont(font);
		g.setColor(Color.WHITE);
		FontMetrics metrics = g.getFontMetrics(font);
		String msg = "BOSS ("+String.valueOf(perc_life) + "%)";
		g.drawString(msg, (40 + (720 - metrics.stringWidth(msg)) / 2), 588);
	}
	

	public boolean[] getModes() {
		return modes;
	}
	

	
	
	
}
