package demo1;

import java.util.List;

public abstract class GenericCharacter extends GenericElement {
	private int atk;
	private int hp;
	private int spd;
	private int maxHp;
	private int fireRate; 
	protected List<MapElement> mappa;

	public GenericCharacter(int x, int y, int atk, int hp, int spd, int fireRate) {
		super(x, y);
		this.atk = atk;
		this.hp = hp;
		this.spd = spd;
		this.maxHp = hp;
		this.fireRate = fireRate;
	}

	public void setMaxHp(int maxHp) {
		this.maxHp = maxHp;
		this.hp = maxHp;
	}

	public int getMaxHp() {
		return this.maxHp;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getSpd() {
		return spd;
	}

	public void setSpd(int spd) {
		this.spd = spd;
	}
	
	public int getFireRate() {
		return fireRate;
	}

	public void setFireRate(int fireRate) {
		this.fireRate = fireRate;
	}

	public void setMappa(List<MapElement> mappa) {
		this.mappa = mappa;
	}
	
	public void moveX() {
	}

	public void moveY() {
	}

}
