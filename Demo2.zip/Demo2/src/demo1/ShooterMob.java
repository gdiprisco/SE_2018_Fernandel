package demo1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class ShooterMob extends GenericMob {
	private List<Shot> shots;
	private StrategyContextMob strategyContextMob; // strategy pattern context
	
	// ANIMATION
	private BufferedImage[] movement = { ShooterSprite.getSprite(0, 0), ShooterSprite.getSprite(1, 0) };	
	private Animation moveanimation;

	public ShooterMob(int x, int y, int diff) {
		super(x, y);

		// set statistics for mob
		super.setMaxHp(super.generateStats(diff));
		super.setAtk(super.generateStats(diff));
		super.setSpd(0);
		// set list of shots
		shots = new ArrayList<>();
		// context for strategy pattern applied to mobs
		strategyContextMob = new StrategyContextMob();
		ConcreteStrategyShooter css = new ConcreteStrategyShooter();
		strategyContextMob.setMobStrategy(css);
		moveanimation = new Animation(movement,css.getFireRate());
		initShooterMob();
	}

	private void initShooterMob() {
		this.setImage(moveanimation.getSprite());
		moveanimation.start();
		getImageDimensions();
	}
	
	@Override
	public BufferedImage getImage() {
		return moveanimation.getSprite();
	}

	// getter for the shot list
	public List<Shot> GetShots() {
		return shots;
	}

	/// Updates the position for the mobs shooting
	public void update(int mc_x, int mc_y) {
		strategyContextMob.StrategyExecute(mc_x, mc_y, this);
		moveanimation.update();
	}

	@Override
	public void drawMobHp(Graphics g) {
		// TODO Auto-generated method stub
		int i;
		int step = getWidth() / getMaxHp();
		for (i = 0; i < getHp(); i++) {
			g.setColor(Color.white);
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
			g.setColor(Color.blue);
			g.fillRect(getX() + 1 + i * step, getY() + height + 6, getWidth() / getMaxHp() - 1, 9);
		}
		g.setColor(Color.white);
		for (; i < getMaxHp(); i++) {
			g.drawRect(getX() + i * step, getY() + height + 5, step, 10);
		}
		moveanimation.update();
	}
	
}
