package demo1;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;

public class MapGenerator {

	private List<MapElement> mapele;
	private List<Rectangle> notStackable;

	// BOUND OF RANDOM NUMBER
	private static final int MIN = 1;
	private static final int MAX_X = 18;
	private static final int MAX_Y = 13;
	private static final int MIN_BLOCK = 0;
	private static final int MAX_BLOCK = 6;
	private static final int MIN_NUM_BLOCK = 1;
	private static final int MAX_NUM_BLOCK = 10;

	// LIST OF IMAGES STRINGS
	private static final String[] imageList = { "src/assets/box_40x40.png", "src/assets/box_40x80.png",
			"src/assets/box_40x120.png", "src/assets/box_40x160.png", "src/assets/box_80x40.png",
			"src/assets/box_120x40.png", "src/assets/box_160x40.png" };

	private BufferedImage background;
	private Random r = new Random();

	// Constructor
	public MapGenerator() {
		notStackable = new ArrayList<Rectangle>();
		try {
			background = ImageIO.read(new File("src/assets/back3_800x600.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Function that generate randomly the scenario
	private MapElement obstacleGenerator(int num_block) {
		String img = imageList[num_block];
		MapElement mp = new MapElement(0, 0, img);
		setRandom(mp);
		return mp;
	}

	// Function that avoids comparing the blocks on the character or mobs
	private void setRandom(MapElement mp) {
		do {
			int mol_x = r.nextInt((MAX_X - MIN) + 1) + MIN;

			int mol_y = r.nextInt((MAX_Y - MIN) + 1) + MIN;
			int x = 40 * mol_x;
			int y = 40 * mol_y;

			mp.setX(x);
			mp.setY(y);

		} while (checkMinDist(mp.getBounds()) || checkCollision(mp.getBounds()));
	}

	// Function that checks if the blocks collide on the mob or character
	private boolean checkCollision(Rectangle rect) {
		for (MapElement mp : mapele) {
			Rectangle r = mp.getBounds();
			if (r.intersects(rect)) {
				return true;
			}

		}
		for (Rectangle m : notStackable) {
			Rectangle r2 = m.getBounds();
			if (r2.intersects(rect))
				return true;
		}
		return false;
	}
	
	// Function that checks if the blocks collide with dropped items
	private boolean checkCollisionWithDrop(List<GenericItem> droplist, Rectangle rect) {
		for(GenericItem gi : droplist) {
			if(rect.intersects(gi.getBounds())) {
				return true;
			}
		}
		return false;
	}


	// Function that verifies if the blocks are, between them, at a distance that
	// allows the passage of the character
	private boolean checkMinDist(Rectangle rect) {
		for (MapElement mp : mapele) {
			Rectangle r = mp.getBounds();
			if (Math.abs(rect.getX() - (r.getX() + r.getWidth())) < 40
					|| Math.abs(r.getX() - (rect.getX() + rect.getWidth())) < 40
					|| Math.abs(rect.getY() - (r.getY() + r.getHeight())) < 40
					|| Math.abs(r.getY() - (rect.getY() + rect.getHeight())) < 40) {
				return true;
			}
		}
		return false;

	}

	// Function to init all map elements
	private List<MapElement> initMap() {
		mapele = new ArrayList<MapElement>();
		int NUM_OF_BLOCK = r.nextInt((MAX_NUM_BLOCK - MIN_NUM_BLOCK) + 1) + MIN_NUM_BLOCK;
		int NUM;

		for (int i = 0; i < NUM_OF_BLOCK; i++) {
			NUM = r.nextInt((MAX_BLOCK - MIN_BLOCK) + 1) + MIN_BLOCK;
			MapElement newObstacle = obstacleGenerator(NUM);
			if (newObstacle != null) {
				mapele.add(newObstacle);
			}
		}
		return mapele;
	}

	// Function that return list of MapElement witch contain borders
	public List<MapElement> getBorders() {
		List<MapElement> borders = new ArrayList<MapElement>();
		borders.add(new MapElement(0, 0, "src/assets/board_up.png"));
		borders.add(new MapElement(0, 560, "src/assets/board_down.png"));
		borders.add(new MapElement(0, 0, "src/assets/board_left.png"));
		borders.add(new MapElement(760, 0, "src/assets/board_right.png"));
		return borders;
	}

	// Function that return list of MapElement witch contain MainRoom Elements
	public List<MapElement> getMainRoomMap() {
		mapele = new ArrayList<MapElement>();
		mapele.add(new MapElement(160, 40, "src/assets/doorbox_40x40.png")); // DUNGEON
		mapele.add(new MapElement(350, 40, "src/assets/doorbox_40x40.png")); // SURVIVAL
		mapele.add(new MapElement(300, 275, "src/assets/chest_closed.png")); 
		mapele.add(new MapElement(300, 275, "src/assets/chest_opened.png"));
		mapele.add(new MapElement(540, 40, "src/assets/doorbox_40x40.png")); // BOSSRUSH
		
		// DRAW IRON BAR BETWEEN DOORS
		for(int i = 0; i < 4; i++) {
			mapele.add(new MapElement(40+(30*i),50,"src/assets/iron_bar2.png"));
		}
		for(int i = 0; i < 5; i++) {
			mapele.add(new MapElement(200+(30*i),50,"src/assets/iron_bar2.png"));
		}
		for(int i = 0; i < 5; i++) {
			mapele.add(new MapElement(390+(30*i),50,"src/assets/iron_bar2.png"));
		}
		for(int i = 0; i < 6; i++) {
			mapele.add(new MapElement(580+(30*i),50,"src/assets/iron_bar2.png"));
		}
		
		// DRAW MODALITY SIGN
		mapele.add(new MapElement(210,55, "src/assets/dungeon_sign.png"));
		mapele.add(new MapElement(400,55, "src/assets/survival_sign.png"));
		mapele.add(new MapElement(590,55, "src/assets/boss_sign.png"));
		mapele.get(3).setVisible(false);
		return mapele;
	}

	// Function that return list of MapElement witch contain ChestContext Elements
	public List<MapElement> getChestMap() {
		mapele = new ArrayList<MapElement>();
		mapele.add(new MapElement(0, 0, "src/assets/book.gif"));
		return mapele;
	}

	public List<MapElement> getRandomMap() {
		return initMap();
	}

	public BufferedImage getBackground() {
		return background;
	}

	public MapElement getDoor(List<GenericItem> droplist, boolean half) {
		MapElement trapdoor = new MapElement(375, 275, "src/assets/trapdoor_40x40.png");
		do {
			setRandom(trapdoor);
		} while(checkCollisionWithDrop(droplist,trapdoor.getBounds()) || checkHalf(trapdoor.getX(),half));
		return trapdoor;
	}
	
	private boolean checkHalf(int trapx, boolean half) {
		if((half && trapx <= 400) || (!half && trapx > 400)) {
			return true;
		} 
		return false;
	}
	
	public void addNotStackable(Rectangle rectangle) {
		notStackable.add(rectangle);
	}

	public boolean removeNotStackable(Rectangle rectangle) {
		if (notStackable.remove(rectangle))
			return true;
		return false;
	}

	public void clearNotStackable() {
		if (!notStackable.isEmpty())
			notStackable.clear();
	}

}
