package demo1;

import java.awt.EventQueue;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.io.IOException;
import javax.swing.JFrame;

public class MainEx extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Board board = null;
	private static boolean wasd_bug = false;

	public MainEx() {
		initUI();
	}

	public void initUI() {
		board = new Board();
		add(board);
		setResizable(false);
		pack();

		setTitle("Game Project");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Runtime.getRuntime().addShutdownHook(new Thread() {

			@Override
			public void run() {
				if (System.getProperty("os.name").startsWith("Mac OS")) {
					enableMacWASD();
				}
			}

		});

		this.addWindowFocusListener(new WindowFocusListener() {

			@Override
			public void windowGainedFocus(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowLostFocus(WindowEvent e) {
				// TODO Auto-generated method stub
				if (board != null && !board.getPause()) {
					board.setPause(true);
				}
			}

		});
	}

	// This method disable or enable an option on Mac OS system
	// that cause a bug on a specific key.
	private static void disableMacWASD() {
		try {
			Runtime.getRuntime().exec("defaults write -g ApplePressAndHoldEnabled -bool false");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void enableMacWASD() {
		if (!wasd_bug) {
			try {
				Runtime.getRuntime().exec("defaults write -g ApplePressAndHoldEnabled -bool true");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			wasd_bug = true;
		}

	}

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			if (System.getProperty("os.name").startsWith("Mac OS")) {
				disableMacWASD();
			}
			MainEx ex = new MainEx();
			ex.setVisible(true);
		});
	}

}
