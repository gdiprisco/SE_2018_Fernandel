package demo1;

public class Laser extends GenericElement {

	public Laser(int x,int y,String ImageName) {
		super(x,y);
		initLaser(ImageName);
	}
	
	private void initLaser(String ImageName) {
		loadImage("src/images/"+ImageName+".png");
		getImageDimensions();
	}
	
	
}
