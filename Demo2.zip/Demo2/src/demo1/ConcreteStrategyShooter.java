package demo1;

import interfaces.*;

public class ConcreteStrategyShooter implements MobStrategy{
	private int shooterMobStop = 0;
	private GenericMob mob;
	private int fireRate = 200;

	public void shoot() {
		if (mob.getInGame()) {
			mob.GetShots().add(new Shot(mob.getX() + mob.getWidth() / 2, mob.getY(), 0, true));
			mob.GetShots().add(new Shot(mob.getX() + mob.getWidth() / 2, mob.getY() + mob.getHeight(), 1, true));
			mob.GetShots().add(new Shot(mob.getX(), mob.getY() + mob.getHeight() / 2, 2, true));
			mob.GetShots().add(new Shot(mob.getX() + mob.getWidth(), mob.getY() + mob.getHeight() / 2, 3, true));
		}

	}
	
	public void setFireRate(int firerate) {
		if(firerate >= 20) 
			this.fireRate = firerate;
	}
	
	public int getFireRate() {
		return this.fireRate;
	}
	
	
	/// Updates the position for the mobs shooting
	public void update(int mc_x, int mc_y, GenericMob mob) {
		this.mob = mob;
		
		if (shooterMobStop == 0) {
			shoot();
			shooterMobStop = fireRate;
		} else
			shooterMobStop--;
		for (int i = 0; i < mob.GetShots().size(); i++) {
			Shot s = mob.GetShots().get(i);
			if (mob.GetShots().get(i).isVisible())
				switch (s.getDirection()) {
				case 0:
					s.moveUp();
					break;
				case 1:
					s.moveDown();
					break;
				case 2:
					s.moveLeft();
					break;
				case 3:
					s.moveRight();
					break;
				}
			else
				mob.GetShots().remove(i);
		}
	}
	
}
