package demo1;

import java.util.HashMap;
import java.util.Map;

public abstract class GenericItem extends GenericElement {

	private boolean equipped;
	private int rarity;
	private Map<Integer, Integer> attributes;
	private String[] type_str = {"Attack","Life","Speed"};
	private String[] rarity_str = {"Normal","Magic","Rare","Legendary","Unique"};

	public GenericItem(int x, int y) {
		super(x, y);
		equipped = false;
		attributes = new HashMap<Integer, Integer>();
		rarity = -1;
		// TODO Auto-generated constructor stub
	}

	public void setAllAttributes(Map<Integer, Integer> attributes) {
		this.attributes = attributes;
	}

	public Map<Integer, Integer> getAllAttributes() {
		return this.attributes;
	}

	public boolean getEquipped() {
		return this.equipped;
	}

	public void setEquipped(boolean equipped) {
		this.equipped = equipped;
	}

	public void addAttribute(int type, int value) {
		attributes.put(type, value);
	}

	public int getType() {
		return -1;
	}

	public void removeAttribute(int type) {
		attributes.remove(type);
	}

	public int getAttribute(int type) {
		return attributes.get(type);
	}

	public int getRarity() {
		return this.rarity;
	}

	public void setRarity(int rarity) {
		this.rarity = rarity;
	}

	@Override
	public String toString() {
		String attr = String.valueOf(attributes.get(getType()+1));
		String type = type_str[getType()];
		String rarity = rarity_str[getRarity()-1];
		return "["+rarity+"]  " + type + " = " + attr;
	}
}
