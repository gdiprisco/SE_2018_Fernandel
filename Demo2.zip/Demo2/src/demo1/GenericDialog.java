package demo1;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.Observable;

import javax.imageio.ImageIO;

public class GenericDialog extends Observable {
	private BufferedImage background;
	private int SELECTED_ANSWER = 0;
	private static final int OK_ANSWER = 3;
	private static final int X_YES = 340;
	private static final int X_NO = 440;
	private static final int Y = 350;
	private static final String YES = "YES";
	private static final String NO = "NO";
	private int TYPE;

	public void showDialog(Graphics g, ImageObserver observer, String msg, int type) {
		try {
			background = ImageIO.read(new File("src/assets/dialog_back.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Font font = new Font("Helvetica", Font.BOLD, 20);
		this.TYPE = type;
		if (g != null && observer != null) {
			g.setFont(font);
			g.drawImage(background, 200, 200, observer);
			drawAnswers(g);
			if (TYPE < 2) {
				drawMessage(g, msg, font, 0, 0);
			} else {
				drawMessage(g, msg, font, 0, -50);
			}
		}

	}

	public void dialogKeyPressed(KeyEvent e) {
		if (TYPE == 0) {
			if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
				if (SELECTED_ANSWER == 1)
					SELECTED_ANSWER--;
			}
			if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
				if (SELECTED_ANSWER == 0)
					SELECTED_ANSWER++;
			}
		} else if (TYPE == 2) {
			if (e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_UP) {
				if (SELECTED_ANSWER == 1)
					SELECTED_ANSWER--;
			}
			if (e.getKeyCode() == KeyEvent.VK_S || e.getKeyCode() == KeyEvent.VK_DOWN) {
				if (SELECTED_ANSWER == 0)
					SELECTED_ANSWER++;
			}
		}
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {

			if (TYPE == 0) {
				setChanged();
				notifyObservers(SELECTED_ANSWER);
			} else if (TYPE == 1) {
				setChanged();
				notifyObservers(OK_ANSWER);
			} else if (TYPE == 2) {
				setChanged();
				notifyObservers(SELECTED_ANSWER + 5);
			}
			SELECTED_ANSWER = 0;
		}

	}

	public void drawMessage(Graphics g, String msg, Font font, int dx, int dy) {
		g.setColor(Color.BLACK);
		FontMetrics metrics = g.getFontMetrics(font);
		// Determine the X coordinate for the text
		int x = 200 + (400 - metrics.stringWidth(msg)) / 2;
		// Determine the Y coordinate for the text (note we add the ascent, as in java
		// 2d 0 is top of the screen)
		int y = 200 + ((200 - metrics.getHeight()) / 2) + metrics.getAscent();
		// Set the font
		// Draw the String
		g.drawString(msg, x + dx, y + dy);
	}

	private void drawAnswers(Graphics g) {
		if (TYPE == 0) {
			if (SELECTED_ANSWER == 0) {
				g.setColor(Color.BLUE);
				g.fillRect(X_YES - 5, Y - 19, 50, 25);
				g.setColor(Color.WHITE);
				g.drawString(YES, X_YES, Y);
				g.setColor(Color.BLACK);
				g.drawString(NO, X_NO, Y);
			} else {
				g.setColor(Color.BLUE);
				g.fillRect(X_NO - 10, Y - 19, 50, 25);
				g.setColor(Color.BLACK);
				g.drawString(YES, X_YES, Y);
				g.setColor(Color.WHITE);
				g.drawString(NO, X_NO, Y);
			}
		} else if (TYPE == 1) {
			g.setColor(Color.BLUE);
			g.fillRect(375, Y - 19, 50, 25);
			g.setColor(Color.WHITE);
			g.drawString("OK", 385, Y);
		} else if (TYPE == 2) {
			Font font = new Font("Helvetica", Font.BOLD, 20);
			g.setFont(font);
			FontMetrics metrics = g.getFontMetrics(font);
			if (SELECTED_ANSWER == 0) {
				// Determine the X coordinate for the text
				int x = 200 + (400 - metrics.stringWidth("RESUME")) / 2;
				// Determine the Y coordinate for the text (note we add the ascent, as in java
				// 2d 0 is top of the screen)
				int y = 200 + ((200 - metrics.getHeight()) / 2) + metrics.getAscent();
				g.setColor(Color.BLUE);
				g.fillRect(x - 10, y - 18, metrics.stringWidth("RESUME") + 20, metrics.getHeight() + 1);

				g.setColor(Color.WHITE);
				g.drawString("RESUME", x, y);

				// Determine the X coordinate for the text
				int x2 = 200 + (400 - metrics.stringWidth("EXIT")) / 2;
				// Determine the Y coordinate for the text (note we add the ascent, as in java
				// 2d 0 is top of the screen)
				int y2 = 200 + ((200 - metrics.getHeight()) / 2) + metrics.getAscent();

				g.setColor(Color.BLACK);
				g.drawString("EXIT", x2, y2 + 25);
			} else {
				// Determine the X coordinate for the text
				int x = 200 + (400 - metrics.stringWidth("RESUME")) / 2;
				// Determine the Y coordinate for the text (note we add the ascent, as in java
				// 2d 0 is top of the screen)
				int y = 200 + ((200 - metrics.getHeight()) / 2) + metrics.getAscent();

				g.setColor(Color.BLACK);
				g.drawString("RESUME", x, y);

				// Determine the X coordinate for the text
				int x2 = 200 + (400 - metrics.stringWidth("EXIT")) / 2;
				// Determine the Y coordinate for the text (note we add the ascent, as in java
				// 2d 0 is top of the screen)
				int y2 = 200 + ((200 - metrics.getHeight()) / 2) + metrics.getAscent();

				g.setColor(Color.BLUE);
				g.fillRect(x2 - 10, y2 + 7, metrics.stringWidth("EXIT") + 20, metrics.getHeight() + 1);

				g.setColor(Color.WHITE);
				g.drawString("EXIT", x2, y2 + 25);
			}
		}
	}

}
