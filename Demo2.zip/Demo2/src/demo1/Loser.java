package demo1;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

public class Loser extends GenericElement {

	private final static int LOSER_X = 325; // x position of losing image
	private final static int LOSER_Y = 416; // y position of losing image
	
	private BufferedImage[] smiling = {LoserSprite.getSprite(0, 0), LoserSprite.getSprite(1, 0)};
	
	private Animation smilingAnimation = new Animation(smiling,10);

	public Loser() {
		super(LOSER_X, LOSER_Y);
		initLoser();
	}

	public void initLoser() {
//		loadImage("src/images/dog.gif");
		setImage(smilingAnimation.getSprite());
		smilingAnimation.start();
		getImageDimensions();
	}
	
	@Override
	public BufferedImage getImage() {
		return smilingAnimation.getSprite();
	}

	/// Draws the objects when the game ends
	public void drawGameOver(Graphics g, ImageObserver observer) {
		g.drawImage(getImage(), getX(), getY(), getWidth(), getHeight(), observer);
		smilingAnimation.update();
	}


}
