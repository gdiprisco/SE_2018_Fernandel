package demo1;

public class RedGem extends GenericItem{

	public RedGem(int x, int y) {
		super(x, y);
		loadImage("src/assets/red.png");
		getImageDimensions();
		// TODO Auto-generated constructor stub
	}
	
	public int getType() {
		return 0;
	}
}
