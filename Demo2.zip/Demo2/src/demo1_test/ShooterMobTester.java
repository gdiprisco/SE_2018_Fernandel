package demo1_test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import demo1.ShooterMob;
import demo1.Shot;

class ShooterMobTester {

	@Test
	public void testShoot() {
		ShooterMob sm = new ShooterMob(100,100,1);
		sm.update(1, 1);
		List<Shot> real_shot = sm.GetShots();
		assertEquals(113,real_shot.get(0).getX());
		assertEquals(98,real_shot.get(0).getY());
		assertEquals(113,real_shot.get(1).getX());
		assertEquals(131,real_shot.get(1).getY());
		assertEquals(98,real_shot.get(2).getX());
		assertEquals(114,real_shot.get(2).getY());
		assertEquals(129,real_shot.get(3).getX());
		assertEquals(114,real_shot.get(3).getY());
		sm.update(1, 1);
		assertEquals(113,real_shot.get(0).getX());
		assertEquals(96,real_shot.get(0).getY());
		assertEquals(113,real_shot.get(1).getX());
		assertEquals(133,real_shot.get(1).getY());
		assertEquals(96,real_shot.get(2).getX());
		assertEquals(114,real_shot.get(2).getY());
		assertEquals(131,real_shot.get(3).getX());
		assertEquals(114,real_shot.get(3).getY());

	}

}
