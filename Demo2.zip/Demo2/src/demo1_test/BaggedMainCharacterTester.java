package demo1_test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Button;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

import demo1.BaggedMainCharacter;
import demo1.BlueGem;
import demo1.GenericItem;
import demo1.ShooterMob;
import demo1.Shot;

public class BaggedMainCharacterTester {
	BaggedMainCharacter mc = new BaggedMainCharacter();
	private List<Shot> shots;

	@SuppressWarnings("deprecation")
	@Test
	public void testMove() throws AWTException {
		int expected_x;
		int expected_y;

		int SPEED = mc.getSpd();

		// test UP
		expected_y = mc.getY() - SPEED;
		Button up = new Button("up");
		mc.keyPressed(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		mc.move();
		mc.keyReleased(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		assertEquals(expected_y, mc.getY());

		// test LEFT
		expected_x = mc.getX() - SPEED;
		Button left = new Button("left");
		mc.keyPressed(new KeyEvent(left, KeyEvent.VK_A, 0, 0, KeyEvent.VK_A));
		mc.move();
		mc.keyReleased(new KeyEvent(left, KeyEvent.VK_A, 0, 0, KeyEvent.VK_A));
		assertEquals(expected_x, mc.getX());

		// test RIGHT
		expected_x = mc.getX() + SPEED;
		Button right = new Button("right");
		mc.keyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		mc.move();
		mc.keyReleased(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		assertEquals(expected_x, mc.getX());

		// test DOWN
		expected_y = mc.getY() + SPEED;
		Button down = new Button("down");
		mc.keyPressed(new KeyEvent(down, KeyEvent.VK_S, 0, 0, KeyEvent.VK_S));
		mc.move();
		mc.keyReleased(new KeyEvent(down, KeyEvent.VK_S, 0, 0, KeyEvent.VK_S));
		assertEquals(expected_y, mc.getY());

	}

	/*
	 * RIFARE IL TEST PER LO SHOT!!
	 */

	@SuppressWarnings("deprecation")
//	@Test
	public void testShot() throws AWTException {
		shots = new ArrayList<>();

		int x = mc.getX();
		int y = mc.getY();
		int width = mc.getWidth();
		int height = mc.getWidth();

		// test UP

		shots.add(new Shot(x + width / 2, y - 10, 0, false));
		Button up = new Button("up");
		mc.keyPressed(new KeyEvent(up, KeyEvent.VK_UP, 0, 0, KeyEvent.VK_UP));
		mc.move();
		mc.keyReleased(new KeyEvent(up, KeyEvent.VK_UP, 0, 0, KeyEvent.VK_UP));
		assertEquals(shots.size(), mc.GetShots().size());

		// test LEFT
		shots.add(new Shot(x - 10, y + height / 2, 2, false));
		Button left = new Button("left");
		mc.keyPressed(new KeyEvent(left, KeyEvent.VK_LEFT, 0, 0, KeyEvent.VK_LEFT));
		mc.move();
		mc.keyReleased(new KeyEvent(left, KeyEvent.VK_LEFT, 0, 0, KeyEvent.VK_LEFT));
		assertEquals(shots.size(), mc.GetShots().size());

		// test RIGHT
		shots.add(new Shot(x + width, y + height / 2, 3, false));
		Button right = new Button("right");
		mc.keyPressed(new KeyEvent(right, KeyEvent.VK_RIGHT, 0, 0, KeyEvent.VK_RIGHT));
		mc.move();
		mc.keyReleased(new KeyEvent(right, KeyEvent.VK_RIGHT, 0, 0, KeyEvent.VK_RIGHT));
		assertEquals(shots.size(), mc.GetShots().size());

		// test DOWN
		shots.add(new Shot(x + width / 2, y + 10 + height, 1, false));
		Button down = new Button("down");
		mc.keyPressed(new KeyEvent(down, KeyEvent.VK_DOWN, 0, 0, KeyEvent.VK_DOWN));
		mc.move();
		mc.keyReleased(new KeyEvent(down, KeyEvent.VK_DOWN, 0, 0, KeyEvent.VK_DOWN));
		assertEquals(shots.size(), mc.GetShots().size());

	}

	@SuppressWarnings("deprecation")
	@Test
	public void testCheckCollisionItems() {
		GenericItem bg = new BlueGem(mc.getX() + mc.getWidth(), mc.getY());
		do {
			Button right = new Button("right");
			mc.keyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
			mc.move();
			mc.keyReleased(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		} while (!mc.checkCollisionItems(bg));
		mc.resetMC();
		assertTrue(mc.getStorage().contains(bg));
		mc.getStorage().remove(bg);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testCheckCollisionItemswithFullStorage() {
		for (int i = 0; i < 70; i++) {
			mc.getStorage().add(new BlueGem(0, 0));
		}
		GenericItem bg = new BlueGem(mc.getX() + mc.getWidth(), mc.getY());
		do {
			Button right = new Button("right");
			mc.keyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
			mc.move();
			mc.keyReleased(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		} while (!mc.checkCollisionItems(bg) && mc.getX() < bg.getX() + bg.getWidth());
		assertFalse(mc.checkCollisionItems(bg));
		mc.setStorage(new ArrayList<GenericItem>());
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testEquipNewItem() {
		mc.setStorage(new ArrayList<GenericItem>());
		Iterator<Integer> it;
		int type;
		int value;
		for (int i = 0; i < 30; i++) {
			ShooterMob sm = new ShooterMob(0, 0, 0);
			mc.getStorage().add(sm.dropItem(1));
		}
		Button right = new Button("right");
		mc.chestKeyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		mc.keyReleased(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		Button enter = new Button("enter");
		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		assertTrue(mc.getStorage().get(1).getEquipped());
		it = mc.getStorage().get(1).getAllAttributes().keySet().iterator();
		type = it.next();
		value = mc.getStorage().get(1).getAttribute(type);
		if (type == 1)
			assertEquals(mc.getAtk(), value + 1);
		else if (type == 2)
			assertEquals(mc.getHp(), value + 1);
		else if (type == 3)
			assertEquals(mc.getSpd(), value + 2);

		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		assertFalse(mc.getStorage().get(8).getEquipped());
		it = mc.getStorage().get(8).getAllAttributes().keySet().iterator();
		type = it.next();
		value = mc.getStorage().get(8).getAttribute(type);
		if (type == 1)
			assertEquals(mc.getAtk(), 1);
		else if (type == 2)
			assertEquals(mc.getHp(), 1);
		else if (type == 3)
			assertEquals(mc.getSpd(), 2);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testEquipOldItem() {
		mc.setStorage(new ArrayList<GenericItem>());
		ShooterMob sm = new ShooterMob(0, 0, 0);
		int value;
		int i = 0;
		while (i != 30) {
			GenericItem gi = sm.dropItem(1);
			if (gi instanceof BlueGem) {
				mc.getStorage().add(gi);
				i++;
			}
		}

		Button enter = new Button("enter");
		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		value = mc.getStorage().get(0).getAttribute(2);
		assertEquals(mc.getHp(), value + 1);

		Button down = new Button("down");
		mc.chestKeyPressed(new KeyEvent(down, KeyEvent.VK_DOWN, 0, 0, KeyEvent.VK_DOWN));
		mc.keyReleased(new KeyEvent(down, KeyEvent.VK_DOWN, 0, 0, KeyEvent.VK_DOWN));
		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		assertFalse(mc.getStorage().get(0).getEquipped());

		assertTrue(mc.getStorage().get(7).getEquipped());

		value = mc.getStorage().get(7).getAttribute(2);
		assertEquals(mc.getHp(), value + 1);

	}

	@SuppressWarnings("deprecation")
	@Test
	public void testUnequipItem() {
		mc.setStorage(new ArrayList<GenericItem>());
		ShooterMob sm = new ShooterMob(0, 0, 0);
		int value;
		int i = 0;
		while (i != 30) {
			GenericItem gi = sm.dropItem(1);
			if (gi instanceof BlueGem) {
				mc.getStorage().add(gi);
				i++;
			}
		}

		Button enter = new Button("enter");
		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		value = mc.getStorage().get(0).getAttribute(2);
		assertEquals(mc.getHp(), value + 1);

		mc.chestKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		mc.keyReleased(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		assertEquals(mc.getHp(), 1);
	}

	/*
	 * MANCA IL TEST PER LA RIMOZIONE DEGLI OGGETTI DALLO ZAINO
	 */
	public void testRemoveItem() {

	}
}
