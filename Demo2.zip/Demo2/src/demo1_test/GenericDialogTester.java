package demo1_test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Button;
import java.awt.event.KeyEvent;
import java.util.Observable;
import java.util.Observer;

import org.junit.jupiter.api.Test;

import demo1.GenericDialog;

class GenericDialogTester implements Observer{
	GenericDialog gd;
	int SELECTED_ANSWER;
	
	@SuppressWarnings("deprecation")
	@Test
	public void testRightAnswerYesNo() {
		gd = new GenericDialog();
		gd.showDialog(null, null, "", 0);
		gd.addObserver(this);
		
		Button enter = new Button("enter");
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(0,SELECTED_ANSWER);
		
		Button right = new Button("right");
		gd.dialogKeyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(1,SELECTED_ANSWER);
		
		Button left = new Button("left");
		gd.dialogKeyPressed(new KeyEvent(left, KeyEvent.VK_A, 0, 0, KeyEvent.VK_A));
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(0,SELECTED_ANSWER);

	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testRightAnswerOk() {
		gd = new GenericDialog();
		gd.showDialog(null, null, "", 1);
		gd.addObserver(this);
		
		Button enter = new Button("enter");
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(3,SELECTED_ANSWER);
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testRightAnswerMenu() {
		gd = new GenericDialog();
		gd.showDialog(null, null, "", 2);
		gd.addObserver(this);
		
		Button enter = new Button("enter");
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(5,SELECTED_ANSWER);
		
		Button down = new Button("down");
		gd.dialogKeyPressed(new KeyEvent(down, KeyEvent.VK_S, 0, 0, KeyEvent.VK_S));
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));
		
		assertEquals(6,SELECTED_ANSWER);
		
		Button up = new Button("up");
		gd.dialogKeyPressed(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		gd.dialogKeyPressed(new KeyEvent(enter, KeyEvent.VK_ENTER, 0, 0, KeyEvent.VK_ENTER));

		assertEquals(5,SELECTED_ANSWER);

	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		SELECTED_ANSWER = (int)arg;
	}

}
