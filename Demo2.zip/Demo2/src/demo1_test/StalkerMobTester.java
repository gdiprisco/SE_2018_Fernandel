package demo1_test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import demo1.MainCharacter;
import demo1.StalkerMob;

class StalkerMobTester {

	@Test
	void test() {
		StalkerMob mob=new StalkerMob(395, 285,1);
		MainCharacter mc=new MainCharacter();
		mob.update(mc.getX(), mc.getY());
		assertEquals(mob.getX(),394);
		assertEquals(mob.getY(),284);		
	}

}
