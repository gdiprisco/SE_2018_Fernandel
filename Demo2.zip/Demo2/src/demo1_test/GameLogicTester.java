package demo1_test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.junit.jupiter.api.Test;

import demo1.GameLogic;
import demo1.GenericMob;
import demo1.MapElement;
import demo1.MapGenerator;

public class GameLogicTester {
	Timer timer = new Timer(); //for test context 3
	int time = 0;
	
	@Test
	void changeModeTest() {
		GameLogic gl = new GameLogic();
		MapGenerator mg= new MapGenerator();
		List<MapElement> map_expected = new ArrayList<MapElement>();
//		RandomMobGenerator rmb = new RandomMobGenerator();
		
		
		map_expected = mg.getMainRoomMap();
		map_expected.addAll(mg.getBorders());
		gl.setContext(0);
		gl.initMap();
		assertEquals(gl.getMap().size(),map_expected.size());
		
	}
	
	@Test
	void AddNewMobTester() {
		GameLogic gl = new  GameLogic();
		gl.initMap();
		
		int beforeSize = gl.getMobs().size();
		gl.addNewMob();
		int afterSize = gl.getMobs().size();
		
		assertTrue(beforeSize < afterSize);
		
	}
	
	@Test
	void CheckGoalTester() {
		GameLogic gl = new GameLogic();
		gl.setContext(2);
		gl.initMap();
				
		List<GenericMob> mobs = gl.getMobs();
		for(GenericMob mob : mobs) {
			mob.setVisible(false);
		}
		
		gl.checkGoal();
		assertTrue(gl.isDoor());
				
	}
	
	@Test
	void goalTest() {
		GameLogic gl = new GameLogic();
		
		//CASE CONTEXT 2 AND 4
		gl.setContext(2);
		gl.initMap();
		int map_size = gl.getMap().size();
		gl.setMobs(new ArrayList<GenericMob>());
		gl.checkGoal();
		assertEquals(map_size+1, gl.getMap().size());
		
		//CASE CONTEXT 3

		gl.setContext(3);
		gl.initMap();
		map_size = gl.getMap().size();
		gl.setMobs(new ArrayList<GenericMob>());

		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				time++;
			}

		}, 1000, 1000);
		while(time != 10) {
			gl.checkGoal();
		}
		if(time>10) {
			assertEquals(map_size+1, gl.getMap().size());
		}
		
	}
	
}
