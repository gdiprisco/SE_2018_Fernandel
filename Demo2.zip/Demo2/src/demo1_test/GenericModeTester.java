package demo1_test;

import static org.junit.Assert.assertTrue;

import java.util.Observable;
import java.util.Observer;

import org.junit.jupiter.api.Test;

import demo1.GenericMode;

class GenericModeTester implements Observer {

	boolean notified = false;
	GenericMode gm;
	long startTime = 0;
	long elapsedTime = 0;
	long elapsedSeconds = 0;
	
	@Test
	public void testStart() {
		gm = new GenericMode(3);
		gm.addObserver(this);
		for (int i = 0; i < 1; i++) {
			int diff = GenericMode.getDifficulty();

			// TODO Auto-generated method stub
			startTime = System.currentTimeMillis();
			gm.start();
			do {
				elapsedTime = (System.currentTimeMillis() - startTime);
				elapsedSeconds = elapsedTime / 1000;
				System.out.println("WAITING 10s");
			} while (elapsedSeconds != (diff * 10));
			gm.increaseDifficulty();
		}
	}
	
	@Test
	public void testGoal() {
		gm = new GenericMode(3);
		gm.start();
		do {
			System.out.println("WAITING 10s");
		}
		while(!gm.goal(0));
		assertTrue(gm.getRemainTime()==0);
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if ((int) arg == 9) {
			equals(elapsedSeconds%5==0);
		}
	}

}
