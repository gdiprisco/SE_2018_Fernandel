package demo1_test;

import demo1.GenericMob;
import demo1.MapElement;
import demo1.MapGenerator;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

import org.junit.jupiter.api.Test;

import demo1.RandomMobGenerator;

class RandomMobGeneratorTester {
	RandomMobGenerator rmb = new RandomMobGenerator();

	@Test
	public void testGetRandomMobs() {
		List<GenericMob> mobs;
		MapGenerator mg = new MapGenerator();
		boolean half = true;

		for (int i = 0; i < 100; i++) {
			List<MapElement>  mappa = mg.getRandomMap();
			rmb.setMappa(mappa);
			mobs = rmb.getRandomMobs(1, half);

			for (GenericMob mob : mobs) {
				if (half) {
					assertTrue(mob.getX() >= 400);
					assertTrue(mob.getX() <= 650);
				} else {
					assertTrue(mob.getX() >= 50);
					assertTrue(mob.getX() <= 350);
				}
				assertTrue(mob.getY() >= 50);
				assertTrue(mob.getY() <= 225 || mob.getY() >= 325);
				assertTrue(mob.getY() <= 500);
				for(MapElement obstacle : mappa) {
					assertFalse(obstacle.getBounds().intersects(mob.getX(),mob.getY(),mob.getWidth()+3,mob.getHeight()+3));
				}
			}
			if(i == 50)
				half = false;
			
		}

	}

}
