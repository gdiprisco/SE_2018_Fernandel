package demo1_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import demo1.GenericItem;
import demo1.RandomItemGenerator;

class RandomItemGeneratorTester {

	@Test
	void test() {
		boolean verifiedType;
		int attributeType;
		int difficulty = 2;
		GenericItem item;
		RandomItemGenerator generator = new RandomItemGenerator();
		int rarityLowerBound = 1;
		int rarityUpperBound = 2+(difficulty/10);
		int valueLowerBound = 1;
		
		for(int i=0; i<100; i++) {
			
			item = generator.getRandomItem(0, 0, difficulty);
			int rarity = item.getRarity();
			
			
			int valueUpperBound = 4+(2*(rarity-1));
			
			boolean rarityLowerVerified = rarity >= rarityLowerBound;
			boolean rarityUpperVerified = rarity <= rarityUpperBound;
			assertTrue(rarityLowerVerified && rarityUpperVerified);
			attributeType = item.getType();
			if(attributeType >= 0 && attributeType <= 2) {
				verifiedType = true;
			} else {
				verifiedType = false;
			}

			assertTrue(verifiedType);
			
			boolean valueLowerVerified = item.getAttribute(attributeType+1) >= valueLowerBound;
			boolean valueUpperVerified = item.getAttribute(attributeType+1) <= valueUpperBound;
			assertTrue(valueLowerVerified && valueUpperVerified);
		}
	}

}
