package demo1_test;

import demo1.LaserMob;
import demo1.MainCharacter;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Rectangle;

import org.junit.jupiter.api.Test;

class LaserMobTester {

	@Test
	void testAbove() {
		LaserMob laserMobX = new LaserMob(450, 275, 1);
		LaserMob laserMobY = new LaserMob(375, 350, 1);

		MainCharacter mainChar = new MainCharacter();

		System.out.println("mc: x_" + mainChar.getX() + " y_" + mainChar.getY());
		System.out.println("lasermobX: x_" + laserMobX.getX() + " y_" + laserMobX.getY());
		System.out.println("lasermobY: x_" + laserMobY.getX() + " y_" + laserMobY.getY());

		Rectangle rMC = mainChar.getBounds();

		// TEST MAINCHARACTER A SINISTRA DI LASERMOBX
		while (laserMobX.getLaser() == null) {
			laserMobX.update(mainChar.getX(), mainChar.getY());
		}
		Rectangle rLaserX = laserMobX.getLaser().getBounds();
		System.out.println("main: " + rMC.getX() + " " + rMC.getMaxX() + " " + rMC.getY() + " " + rMC.getMaxY());
		System.out.println(
				"laserX: " + rLaserX.getX() + " " + rLaserX.getMaxX() + " " + rLaserX.getY() + " " + rLaserX.getMaxY());
		System.out.println(rLaserX.intersects(rMC));
		assertTrue(rLaserX.intersects(rMC));

		mainChar = new MainCharacter();
		rMC = mainChar.getBounds();

		// TEST MAINCHARACTER AL DI SOPRA DI LASERMOBY
		while (laserMobY.getLaser() == null) {
			laserMobY.update(mainChar.getX(), mainChar.getY());
		}
		Rectangle rLaserY = laserMobY.getLaser().getBounds();
		System.out.println(
				"laserY: " + rLaserY.getX() + " " + rLaserY.getMaxX() + " " + rLaserY.getY() + " " + rLaserY.getMaxY());
		System.out.println(rLaserY.intersects(rMC));
		assertTrue(rLaserY.intersects(rMC));

	}

}
