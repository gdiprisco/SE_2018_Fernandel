package demo1_test;

import static org.junit.Assert.assertTrue;

import java.awt.Button;
import java.util.List;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.junit.Test;

import demo1.BaggedMainCharacter;
import demo1.MapElement;

public class MapElementTester {
	private BaggedMainCharacter character = new BaggedMainCharacter();
	private MapElement element = new MapElement(character.getX(), character.getY(), "src/assets/box_40x40.png");
	private List<MapElement> test_map;
	
	@SuppressWarnings("deprecation")
	@Test
	public void checkInFrontCollisionTest() {
		int SPEED = character.getSpd();
		
		test_map = new ArrayList<MapElement>();
		element.setY(character.getY()-element.getHeight()-1);
		test_map.add(element);
							
		Button up = new Button("up");
		character.keyPressed(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		character.move();
		character.keyReleased(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		
		boolean verified = element.checkInFrontOfCollision(character.getBounds(), SPEED);
		assertTrue(verified);
	}
}
