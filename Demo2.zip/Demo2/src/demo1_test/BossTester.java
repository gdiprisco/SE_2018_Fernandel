package demo1_test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import demo1.Boss;

class BossTester {

	@Test
	void changeModeTest() {
		Boss mob=new Boss(395, 285,1);
		mob.update(1, 1);
		mob.setMaxHp(100);
		assertTrue(mob.getModes()[0]);
		assertFalse(mob.getModes()[1]);
		assertFalse(mob.getModes()[2]);
		mob.setHp(50);
		mob.update(1, 1);
		assertTrue(mob.getModes()[0]);
		assertTrue(mob.getModes()[1]);
		assertFalse(mob.getModes()[2]);
		mob.setHp(10);
		mob.update(1, 1);
		assertTrue(mob.getModes()[0]);
		assertTrue(mob.getModes()[1]);
		assertTrue(mob.getModes()[2]);
	}

}
