package demo1_test;

import static org.junit.Assert.assertTrue;

import java.awt.Button;
import java.awt.event.KeyEvent;

import org.junit.jupiter.api.Test;

import demo1.BaggedMainCharacter;
import demo1.GenericMob;
import demo1.ShooterMob;

class GenericMobTester {

	BaggedMainCharacter mc = new BaggedMainCharacter();
	GenericMob gm;
	Button up = new Button("up");
	Button right = new Button("right");
	Button left = new Button("left");
	Button down = new Button("down");

	@SuppressWarnings("deprecation")
	@Test
	public void testCheckMobCollision() {
		gm = new ShooterMob(mc.getX() + mc.getWidth(), mc.getY(), 1);

		do {
			mc.keyPressed(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
			mc.move();
			mc.keyReleased(new KeyEvent(right, KeyEvent.VK_D, 0, 0, KeyEvent.VK_D));
		} while (!gm.checkMobCollision(mc.getBounds(), mc.getSpd()));
		assertTrue(gm.checkMobCollision(mc.getBounds(), mc.getSpd()));

		mc.resetMC();
		gm = new ShooterMob(mc.getX() - mc.getWidth(), mc.getY(), 1);

		do {
			mc.keyPressed(new KeyEvent(left, KeyEvent.VK_A, 0, 0, KeyEvent.VK_A));
			mc.move();
			mc.keyReleased(new KeyEvent(left, KeyEvent.VK_A, 0, 0, KeyEvent.VK_A));
		} while (!gm.checkMobCollision(mc.getBounds(), mc.getSpd()));
		assertTrue(gm.checkMobCollision(mc.getBounds(), mc.getSpd()));

		mc.resetMC();
		gm = new ShooterMob(mc.getX(), mc.getY() + mc.getHeight(), 1);

		do {
			mc.keyPressed(new KeyEvent(down, KeyEvent.VK_S, 0, 0, KeyEvent.VK_S));
			mc.move();
			mc.keyReleased(new KeyEvent(down, KeyEvent.VK_S, 0, 0, KeyEvent.VK_S));
		} while (!gm.checkMobCollision(mc.getBounds(), mc.getSpd()));
		assertTrue(gm.checkMobCollision(mc.getBounds(), mc.getSpd()));

		mc.resetMC();
		gm = new ShooterMob(mc.getX(), mc.getY() - mc.getHeight(), 1);

		do {
			mc.keyPressed(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
			mc.move();
			mc.keyReleased(new KeyEvent(up, KeyEvent.VK_W, 0, 0, KeyEvent.VK_W));
		} while (!gm.checkMobCollision(mc.getBounds(), mc.getSpd()));
		assertTrue(gm.checkMobCollision(mc.getBounds(), mc.getSpd()));

	}

	@Test
	public void testGenerateStats() {
		int diff = 0;
		for (int i = 1; i < 50; i++) {
			diff = i;
			int min = 1 + 2 * (diff - 1);
			int max = 1 + 3 * diff;
			if (max > 10)
				max = 10;
			if (min > 9)
				min = 9;
			for(int j = 0; j < 100; j++) {
				gm = new ShooterMob(0, 0, diff);
				assertTrue(gm.generateStats(diff)>=min);
				assertTrue(gm.generateStats(diff)<=max);
			}
			
		}
	}

}
