package demo1;

public class Mob extends GenericCharacter{
	
	public Mob(int x, int y) {
		super(x,y,1,1,1);
	}
	
}
